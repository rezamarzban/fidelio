# Security notes - Fidelio dbb05f0, patches 0001-0015

This document describes the security hardening applied in the `atecc-support` branch
(base commit `dbb05f06ca8ce606b5de5a1889ef859488ea851d` + patches 0001–0015).

**Verification status:** checked on a host-side test rig and against Microchip’s
CryptoAuthLib sources. **Not tested on real silicon.**

## What these patches defend against

| # | Weakness in dbb05f0 | Fix |
|---|---|---|
| 0001 | Uninitialised stack bytes sent over USB (INIT / VERSION / error frames) | Frames zeroed; proper CTAPHID error frames |
| 0002 | U2F sign-without-presence (p1=0x08); unbounded button wait; handle not checked before button; held button auto-approves; secrets left on error paths | Removed / bounded 30 s / checked first / fresh press required / single scrubbing exit |
| 0003 | Stray continuation frame replays a finished request | Message retired after execution |
| 0004 | authenticatorReset without button; CBOR 32-bit length wrap-around → out-of-bounds read (reproduced with ASan); unbounded CBOR recursion; unvalidated ECDH point; PIN retry spent after comparison; no minimum PIN length; non-constant-time compares | All fixed |
| 0005 | RNG seeded only from floating-pin ADC LSBs; master key could be provisioned from a failed RNG | ROSC jitter + timer mixed through SHA-256; keygen refuses on RNG failure |
| 0006 | `flash_range_program` called with non-page sizes (reads past the structure) | Whole 0xFF-padded pages |
| 0007 | Dead resident-key store / FDO code (attack surface) | Removed; `rk=true` rejected (0x2B) |
| 0008 | CTAPHID: other channels could inject continuation frames; INIT wiped an in-flight message; no channel allocation; reply continuation frames had CID 0; no timeout; no PING/WINK | CID checks, CHANNEL_BUSY, real channels, timeout, PING/WINK/CANCEL |
| 0009 | setPIN on a fresh key needed no physical presence; wrong error codes | Button required; PIN_REQUIRED / PIN_AUTH_INVALID |
| 0010 | Repeated/biased ECDSA nonces leak keys when the RNG is weak | RFC 6979 deterministic nonces (plus release of wolfSSL’s per-signature nonce buffer that otherwise leaked heap on every signature – found with ASan) |
| 0011 | Build not forced to RAM layout; image could grow into key/counter sectors | `copy_to_ram` forced; build fails if image ≥ 0x70000 |
| 0012 | Reset cleared the PIN but kept the master key: a thief could reset (clearing the PIN retry lock) and keep using every credential | Reset rotates the master key (CTAP2: reset invalidates all credentials) |
| 0013 | (optional) Root secret readable from flash | Secure-element mode (ATECC608 on I2C, selected by a GP6–GP7 jumper at power-up): the root secret stays in the chip and all key derivation is computed by it; fail-closed (never falls back to software); chip serial bound at enrolment; enrolment destroys the software master key; U2F counter never goes backwards. See `SE.md` |
| 0014 | No pinned reference for the driver that was cross-checked against Microchip sources | CryptoAuthLib added as a git submodule (pinned to v3.8.0 / `d49c7d5`). **Not linked into the firmware** – present only as reference and for provisioning tools. See licence note in `SE.md`. |
| 0015 | Private keys readable from RP2040 flash/RAM (master key, attestation key in `cert.c`, per-credential keys derived into RAM); software ECDSA | **Hardware-only crypto, model C**: no software mode and no jumper. Every private key (attestation + one per credential) is created inside the ATECC608 and never leaves it; every signature is made by the chip and verified before release; credential ids are opaque random values mapped to chip slots by a flash table bound to the chip serial; the attestation certificate is built and signed on the device; reset destroys the credential keys inside the chip; the chip RNG is mandatory. Cost: ES256 only, credentials limited by chip slots (default 7). See `SE.md` |

## Behaviour changes you will notice

* CTAP2 reset (also the way out of a PIN lock-out) now **INVALIDATES every U2F registration and CTAP2 credential** – you must re-enrol afterwards.
* **There is no software mode any more.** Without a correctly provisioned ATECC608 the device blinks an error code and never enumerates on USB (see `SE.md`).
* **Earlier software-mode registrations cannot be carried over** (re-register); a software master key left in flash by an older version is erased at first boot.
* **ES256 only; at most 7 credentials** with the default slot map (`KEY_STORE_FULL` / U2F `0x6A84` beyond that, until reset).
* **Reset destroys every credential key inside the chip** (fresh random keys replace them).
* Reset only works within 10 s of plugging in, with a button tap.
* setPIN needs a tap.
* U2F “sign without presence” is gone.
* `rk=true` (passkeys / discoverable credentials) is refused – this firmware has no resident-key store.

## What no software patch can fix (read this)

* **Physical access to the board.** Private keys are no longer extractable from flash or RAM, but the RP2040 still has no encrypted flash / secure boot: the **PIN hash**, the **credential table** and the **attestation certificate** are in flash and can be read, deleted or replaced. Someone holding the whole board can also ask the chip to sign for any credential id they know (the chip does not rate-limit). The I2C bus is not encrypted (it carries public keys, digests, signatures - not private keys).
* **Entropy**: credential ids, GenKey and the DRBG seed come from the chip's TRNG (mandatory) mixed with RP2040 noise; the chip's TRNG quality was not measured.
* **U2F attestation is per-device** (inherent to U2F): sites can link your registrations.
* **Side channels / fault injection** on the RP2040 or the chip were not assessed.
* **No claim of being unbreakable.** Best-effort hardening, no independent audit, **never run on a real chip or board**. Test on a spare chip first (locking the chip is irreversible).

## Secure element (patches 0013 and 0015)

`SE.md` is the full description of the hardware-only model (supersedes the optional mode of 0013):

- What runs in the ATECC608 vs what still runs on the RP2040
- Fail-closed behaviour and LED error codes
- Wiring and chip provisioning requirements (slot map, locked zones)
- Limits (unencrypted I2C bus, no rate-limit in the chip, PIN hash and credential table in flash)
- Provisioning requirements: slots 0..7 private P-256, GenKey allowed, PrivWrite forbidden, not readable
- Explicit statement that the driver has been cross-checked against CryptoAuthLib (`lib/hal` + `lib/calib`) but **has never been tested against a real chip**

## CryptoAuthLib submodule (patch 0014)

`lib/cryptoauthlib` is Microchip’s library pinned to commit `d49c7d578efb09d4a498d5ab86839d4c17812f15` (v3.8.0).

It is **not compiled into the firmware**. `CMakeLists.txt` lists sources explicitly and does not touch this directory, so the binary size and licence surface are unchanged.

It is present as:

1. The exact reference the `src/se.c` driver was checked against.
2. A convenient source of Microchip’s official provisioning tools (`python/`, `app/`).

**Licence note:** Microchip’s licence allows use “exclusively with Microchip products” and requires its terms to be redistributed. Fidelio is GPL. Keeping the library as a separate submodule is fine; **linking its code into a firmware image you distribute would combine the two licences**, which do not obviously fit. For personal builds this does not arise. Ask a lawyer before shipping binaries that contain CryptoAuthLib code.
