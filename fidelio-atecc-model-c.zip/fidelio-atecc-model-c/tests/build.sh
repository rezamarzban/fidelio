#!/bin/sh
# usage: build.sh <repo-root> <out-binary> [gcc flags]      env: WOLFSSL=<wolfssl checkout> (default <repo>/lib/wolfssl)
SRC=$1; OUT=$2; shift 2
HERE=$(cd "$(dirname "$0")" && pwd); W=${WOLFSSL:-$SRC/lib/wolfssl}
mkdir -p /tmp/rig_inc
sed 's/^#define WOLFSSL_SP_ARM_THUMB_ASM/\/\/ host/' $SRC/src/user_settings.h > /tmp/rig_inc/user_settings.h
FILES=""; for s in asn wc_port wolfmath hash memory misc ecc hmac coding random aes sha256 sha512 ge_low_mem fe_low_mem ge_operations wc_encrypt pwdbased sp_int sp_c32 kdf logging error; do [ -f $W/wolfcrypt/src/$s.c ] && FILES="$FILES $W/wolfcrypt/src/$s.c"; done
gcc -O1 -g -w "$@" -DWOLFSSL_USER_SETTINGS -I/tmp/rig_inc -I$HERE/stubs -I$SRC/src -I$W -o $OUT $HERE/rig.c $HERE/se_on.c \
  $SRC/src/u2f.c $SRC/src/ctap2.c $SRC/src/cred_store.c $SRC/src/att_cert.c $SRC/src/att_der.c $SRC/src/hw_sign.c $FILES
