import subprocess, os, sys
from fido2.hid import CtapHidDevice, HidDescriptor
class PipeConn:
    def __init__(self, exe, flash, button="toggle"):
        env=dict(os.environ, RIG_BUTTON=button)
        self.p = subprocess.Popen([exe, flash], stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=env)
    def write_packet(self, data):
        data=bytes(data)
        if len(data)==65: data=data[1:]
        self.p.stdin.write(data); self.p.stdin.flush()
    def read_packet(self):
        d=self.p.stdout.read(64)
        if len(d)<64: raise IOError("eof")
        return d
    def close(self):
        try: self.p.stdin.close(); self.p.wait(10)
        except Exception: pass
def open_dev(exe, flash, button="toggle"):
    conn=PipeConn(exe, flash, button)
    desc=HidDescriptor("pipe",0x1234,0x5678,64,64,"fidelio-host","0")
    return CtapHidDevice(desc, conn), conn
