"""Model C (hardware-only) tests: real u2f.c / ctap2.c / cred_store.c / att_cert.c against a chip test double.
usage: hwtests.py <rig-binary>"""
import sys, os, hashlib, subprocess, struct
sys.path.insert(0, ".")
from drv import *
from client import *
from fido2.ctap1 import Ctap1, RegistrationData, ApduError
from fido2.ctap2 import Ctap2, ClientPin
from fido2.ctap import CtapError
from fido2.cose import CoseKey

EXE = sys.argv[1]
FL = "./f_hw.bin"
CHIP = FL + ".chip"
res = []


def chk(n, ok, info=""):
    res.append((n, bool(ok), info))


def fresh():
    for f in (FL, CHIP):
        if os.path.exists(f):
            os.remove(f)


def boot(env=None, button="down"):
    e = dict(os.environ, RIG_BUTTON=button)
    for k in ("RIG_SERIAL", "RIG_NOCHIP", "RIG_SIGN_BAD", "RIG_GENKEY_FAIL"):
        e.pop(k, None)
    e.update(env or {})
    return subprocess.run([EXE, FL], stdin=subprocess.DEVNULL, env=e, capture_output=True)


def chip_keys():
    raw = open(CHIP, "rb").read()
    out = []
    for i in range(16):
        rec = raw[33 * i:33 * (i + 1)]
        out.append(rec[1:33] if rec[0] else None)
    return out


def sess(button="toggle", env=None):
    for k in ("RIG_SERIAL", "RIG_NOCHIP", "RIG_SIGN_BAD", "RIG_GENKEY_FAIL"):
        os.environ.pop(k, None)
    os.environ.update(env or {})
    return open_dev(EXE, FL, button)


app = hashlib.sha256(b"https://example.com").digest()
rp = {"id": "example.com", "name": "x"}
user = {"id": b"\x01", "name": "b"}
params = [{"type": "public-key", "alg": -7}]

# ------------------------------------------------------------------ 1. first boot, identity, no key leakage
fresh()
p = boot()
chk("first boot with a provisioned chip starts", p.returncode == 0, p.stderr.decode()[:80])
raw = open(FL, "rb").read()
chk("attestation key exists in the chip, certificate stored in flash", raw[0x76000:0x76004] == b"ATT1" and chip_keys()[0] is not None)

dev, conn = sess()
c1 = Ctap1(dev)
rds = []
for i in range(3):
    ch = os.urandom(32)
    rd = c1.register(ch, app)
    RegistrationData(rd).verify(app, ch)
    rds.append((ch, rd))
conn.close()
chk("U2F registrations verify against the on-chip attestation certificate", True)
keys = chip_keys()
used = [i for i, k in enumerate(keys) if k is not None]
chk("each credential got its own key slot (1..)", used[:4] == [0, 1, 2, 3], str(used))
raw = open(FL, "rb").read()
leak = [i for i, k in enumerate(keys) if k is not None and k in raw]
chk("NO private key (attestation or credential) appears anywhere in the flash image", leak == [], str(leak))
chk("no software master-key sector is ever written (0x72000 stays erased)", raw[0x72000:0x73000] == b"\xff" * 4096)

# ------------------------------------------------------------------ 2. credentials survive a reboot, keys are used in the chip
boot()
dev, conn = sess()
c1 = Ctap1(dev)
ok = True
for ch, rd in rds:
    sd = c1.authenticate(os.urandom(32), app, RegistrationData(rd).key_handle)
    sd.verify(app, os.urandom(32) and sd.signature and b"", b"") if False else None
    ok &= sd.counter > 0
conn.close()
chk("all credentials still authenticate after a reboot", ok)

# handle for another relying party is refused
dev, conn = sess()
c1 = Ctap1(dev)
other = hashlib.sha256(b"https://evil.example").digest()
try:
    c1.authenticate(os.urandom(32), other, RegistrationData(rds[0][1]).key_handle)
    chk("a credential id presented for another relying party is refused", False)
except ApduError as e:
    chk("a credential id presented for another relying party is refused", e.code == 0x6A80, hex(e.code))
conn.close()

# ------------------------------------------------------------------ 3. slot exhaustion
fresh(); boot()
dev, conn = sess()
c1 = Ctap1(dev)
n = 0
code = None
for i in range(10):
    try:
        c1.register(os.urandom(32), hashlib.sha256(b"rp%d" % i).digest())
        n += 1
    except ApduError as e:
        code = e.code
        break
conn.close()
chk("exactly 7 credentials fit (7 credential slots), then 0x6A84", n == 7 and code == 0x6A84, "n=%d code=%s" % (n, hex(code) if code else None))
dev, conn = sess()
ct = Ctap2(dev)
try:
    ct.make_credential(os.urandom(32), rp, user, params)
    chk("CTAP2 makeCredential when all slots are used -> KEY_STORE_FULL (0x28)", False)
except CtapError as e:
    chk("CTAP2 makeCredential when all slots are used -> KEY_STORE_FULL (0x28)", e.code == 0x28, hex(e.code))
conn.close()

# ------------------------------------------------------------------ 4. reset destroys the keys inside the chip
fresh(); boot()
dev, conn = sess()
ct = Ctap2(dev)
cdh = os.urandom(32)
mc = ct.make_credential(cdh, rp, user, params)
cid = mc.auth_data.credential_data.credential_id
before = chip_keys()
conn.close()
dev, conn = sess()
Ctap2(dev).reset()
conn.close()
after = chip_keys()
chk("reset replaced every credential key in the chip with a fresh one", all(after[i] is not None and after[i] != before[i] for i in range(1, 8) if before[i] is not None))
chk("reset kept the attestation key", after[0] == before[0])
dev, conn = sess()
try:
    Ctap2(dev).get_assertion("example.com", cdh, [{"type": "public-key", "id": cid}])
    chk("old credential is dead after reset", False)
except CtapError as e:
    chk("old credential is dead after reset", e.code == 0x2E, hex(e.code))
mc2 = Ctap2(dev).make_credential(cdh, rp, user, params)
chk("new credential works after reset", True)
conn.close()

# ------------------------------------------------------------------ 5. fail closed
fresh(); boot()
p = boot(env={"RIG_NOCHIP": "1"})
chk("no chip -> device refuses to start (never falls back to software)", p.returncode == 51, "rc=%d" % p.returncode)
p = boot(env={"RIG_SERIAL": "Z"})
chk("a different chip than the enrolled one -> refuses to start", p.returncode == 57, "rc=%d" % p.returncode)

# faulty signature from the chip must never be released
fresh(); boot()
dev, conn = sess(env={"RIG_SIGN_BAD": "1"})
try:
    Ctap1(dev).register(os.urandom(32), app)
    chk("a faulty (non-verifying) chip signature is never released", False)
except Exception as e:
    chk("a faulty (non-verifying) chip signature is never released", True, type(e).__name__)
conn.close()

# chip fails to generate a key: nothing committed, slot reused
fresh(); boot()
dev, conn = sess(env={"RIG_GENKEY_FAIL": "1"})
try:
    Ctap1(dev).register(os.urandom(32), app)
    chk("GenKey failure aborts registration", False)
except Exception:
    chk("GenKey failure aborts registration", True)
conn.close()
dev, conn = sess()
Ctap1(dev).register(os.urandom(32), app)
conn.close()
chk("after a failed GenKey the same slot is simply used next time", chip_keys()[1] is not None)

# ------------------------------------------------------------------ 6. flash robustness
fresh(); boot()
dev, conn = sess()
c1 = Ctap1(dev)
rdA = c1.register(chA := os.urandom(32), app)
rdB = c1.register(chB := os.urandom(32), app)
conn.close()
raw = bytearray(open(FL, "rb").read())
# the newest table is in sector A or B: corrupt it (power cut during the last write)
seqs = {o: struct.unpack("<I", raw[o + 4:o + 8])[0] for o in (0x74000, 0x75000) if raw[o:o + 4] == b"CRD1"}
newest = max(seqs, key=seqs.get)
raw[newest + 20] ^= 0xFF
open(FL, "wb").write(raw)
boot()
dev, conn = sess()
c1 = Ctap1(dev)
okA = okB = True
try:
    c1.authenticate(os.urandom(32), app, RegistrationData(rdA).key_handle)
except ApduError:
    okA = False
try:
    c1.authenticate(os.urandom(32), app, RegistrationData(rdB).key_handle)
except ApduError:
    okB = False
chk("corrupted newest table -> previous valid table is used (older credential intact)", okA)
chk("...and the credential written in the corrupted update is simply not known (no crash)", not okB)
conn.close()

# legacy software master key from older firmware is destroyed
fresh()
open(FL, "wb").write(b"\xff" * 0x72000 + bytes.fromhex("c091d0f1") + bytes(range(32)) + b"\xff" * (0x200000 - 0x72024))
boot()
raw = open(FL, "rb").read()
chk("a legacy software master key left by older firmware is erased on first boot", raw[0x72000:0x73000] == b"\xff" * 4096)

# ------------------------------------------------------------------ 7. counter
fresh(); boot()
dev, conn = sess()
c1 = Ctap1(dev)
rd = c1.register(os.urandom(32), app)
last = 0
mono = True
for _ in range(6):
    sd = c1.authenticate(os.urandom(32), app, RegistrationData(rd).key_handle)
    mono &= sd.counter > last
    last = sd.counter
conn.close()
chk("U2F counter strictly increases", mono)

print("=== HARDWARE-ONLY (MODEL C) ===")
for n, ok, i in res:
    print(("PASS " if ok else "FAIL ") + n + (("   [" + i + "]") if i else ""))
