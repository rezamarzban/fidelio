#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
typedef struct i2c_inst i2c_inst_t;
extern i2c_inst_t i2c0_inst;
#define i2c0 (&i2c0_inst)
unsigned i2c_init(i2c_inst_t*i, unsigned b);
int i2c_write_timeout_us(i2c_inst_t*i,uint8_t a,const uint8_t*d,size_t n,bool nostop,uint32_t t);
int i2c_read_timeout_us(i2c_inst_t*i,uint8_t a,uint8_t*d,size_t n,bool nostop,uint32_t t);
