#pragma once
#include <stdint.h>
#define GPIO_OUT 1
#define GPIO_IN 0
#define GPIO_FUNC_I2C 3
#define GPIO_FUNC_SIO 5
void gpio_init(uint32_t p); void gpio_set_dir(uint32_t p,int o); void gpio_pull_up(uint32_t p); void gpio_disable_pulls(uint32_t p);
void gpio_set_function(uint32_t p,int f); void gpio_put(uint32_t p,int v); int gpio_get(uint32_t p);
