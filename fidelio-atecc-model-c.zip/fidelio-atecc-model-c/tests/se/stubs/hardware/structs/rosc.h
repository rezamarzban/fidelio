#pragma once
#include <stdint.h>
typedef struct { volatile uint32_t randombit; } rosc_hw_t;
extern rosc_hw_t *rosc_hw;
