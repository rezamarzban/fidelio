#pragma once
#include <stdint.h>
void adc_init(void); void adc_gpio_init(uint32_t p); void adc_select_input(uint32_t i); uint16_t adc_read(void);
