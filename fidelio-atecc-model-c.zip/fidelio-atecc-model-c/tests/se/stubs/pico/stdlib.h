#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
void sleep_us(uint64_t u); void sleep_ms(uint32_t m); void busy_wait_us_32(uint32_t u);
uint32_t time_us_32(void); uint64_t time_us_64(void);
