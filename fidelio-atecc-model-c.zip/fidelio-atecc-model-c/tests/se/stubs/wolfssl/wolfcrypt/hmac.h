#pragma once
#include "settings.h"
typedef struct { int x; } Hmac;
#define SHA256 2
int wc_HmacInit(Hmac*h,void*a,int b); int wc_HmacSetKey(Hmac*h,int t,const uint8_t*k,uint32_t n);
int wc_HmacUpdate(Hmac*h,const uint8_t*d,uint32_t n); int wc_HmacFinal(Hmac*h,uint8_t*o); void wc_HmacFree(Hmac*h);
