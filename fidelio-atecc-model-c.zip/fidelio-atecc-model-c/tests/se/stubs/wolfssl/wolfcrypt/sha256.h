#pragma once
#include "settings.h"
typedef struct { int x; } wc_Sha256;
#define WC_SHA256_DIGEST_SIZE 32
int wc_InitSha256(wc_Sha256*s); int wc_Sha256Update(wc_Sha256*s,const void*d,word32 n); int wc_Sha256Final(wc_Sha256*s,uint8_t*o); void wc_Sha256Free(wc_Sha256*s);
