#pragma once
#include <stdint.h>
typedef unsigned char byte; typedef uint32_t word32;
