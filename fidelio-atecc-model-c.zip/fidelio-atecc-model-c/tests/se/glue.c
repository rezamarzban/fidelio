/* Host glue: Pico SDK I2C/GPIO/time routed to Python (the chip model). */
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
typedef struct i2c_inst { int x; } i2c_inst_t; i2c_inst_t i2c0_inst;
typedef int (*wr_cb)(uint8_t addr, const uint8_t *d, size_t n);
typedef int (*rd_cb)(uint8_t addr, uint8_t *d, size_t n);
typedef void (*wake_cb)(uint64_t low_us);
wr_cb g_wr; rd_cb g_rd; wake_cb g_wake;
static int sda_mode_sio, sda_val = 1, sda_low; static uint64_t sda_low_t0; uint64_t g_time_us;
void set_cbs(wr_cb w, rd_cb r, wake_cb wk){ g_wr=w; g_rd=r; g_wake=wk; }
unsigned i2c_init(i2c_inst_t*i, unsigned b){(void)i;return b;}
int i2c_write_timeout_us(i2c_inst_t*i,uint8_t a,const uint8_t*d,size_t n,bool ns,uint32_t t){(void)i;(void)ns;(void)t;return g_wr(a,d,n);}
int i2c_read_timeout_us(i2c_inst_t*i,uint8_t a,uint8_t*d,size_t n,bool ns,uint32_t t){(void)i;(void)ns;(void)t;return g_rd(a,d,n);}
void gpio_init(uint32_t p){(void)p;} void gpio_set_dir(uint32_t p,int o){(void)p;(void)o;} void gpio_pull_up(uint32_t p){(void)p;}
void gpio_disable_pulls(uint32_t p){(void)p;}
void gpio_set_function(uint32_t p,int f){ if(p==4){ if(f==5){ sda_mode_sio=1; if(sda_val==0 && !sda_low){ sda_low=1; sda_low_t0=g_time_us; } }
    else { if(sda_mode_sio && sda_low){ g_wake(g_time_us - sda_low_t0); } sda_mode_sio=0; sda_low=0; sda_val=1; } } }
void gpio_put(uint32_t p,int v){ if(p==4){ sda_val=v; if(sda_mode_sio && v==0 && !sda_low){ sda_low=1; sda_low_t0=g_time_us; } } }
int gpio_get(uint32_t p){ (void)p; return 1; }
void sleep_us(uint64_t u){ g_time_us+=u; } void sleep_ms(uint32_t m){ g_time_us+=(uint64_t)m*1000; }
