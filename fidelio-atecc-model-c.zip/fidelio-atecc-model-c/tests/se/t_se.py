"""se.c (model C) against a behavioural model of the ATECC608 command protocol.
Framing, CRC16, wake/sleep, busy NACK, the 2-byte-head read pointer, statuses - plus GenKey / Nonce / Sign with REAL
P-256 (python 'cryptography') so signatures are checked for real.  Written from the datasheet / cryptoauthlib; NOT validated on silicon."""
import ctypes, hashlib, os, random, sys
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import Prehashed, decode_dss_signature
from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidSignature

lib = ctypes.CDLL("./libse.so")
WR = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_uint8, ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t)
RD = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_uint8, ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t)
WK = ctypes.CFUNCTYPE(None, ctypes.c_uint64)
lib.set_cbs.argtypes = [WR, RD, WK]
lib.se_init.restype = ctypes.c_int; lib.se_active.restype = ctypes.c_bool
lib.se_random32.argtypes = [ctypes.c_char_p]; lib.se_serial.argtypes = [ctypes.c_char_p]
lib.se_pubkey.argtypes = [ctypes.c_uint8, ctypes.c_char_p, ctypes.c_char_p]
lib.se_genkey.argtypes = [ctypes.c_uint8, ctypes.c_char_p, ctypes.c_char_p]
lib.se_sign.argtypes = [ctypes.c_uint8, ctypes.c_char_p, ctypes.c_char_p]

ATT, CRED_FIRST, CRED_N = 0, 1, 7        # se.h defaults


def crc16(data):
    crc = 0
    for b in data:
        m = 1
        while m < 256:
            bit = 1 if (b & m) else 0; top = crc >> 15; crc = (crc << 1) & 0xFFFF
            if bit != top: crc ^= 0x8005
            m <<= 1
    return crc


def frame(payload):
    body = bytes([len(payload) + 3]) + payload
    c = crc16(body); return body + bytes([c & 0xFF, c >> 8])


def good_config(att=True):
    """Config zone with SlotConfig/KeyConfig for slots 0..7 the way SE.md requires; bytes 86/87 = locked."""
    c = bytearray(128)
    for s in range(16):
        if s <= 7:
            sc = 0x0001 | 0x0080 | 0x0100            # ReadKey[0] ext-sign, IsSecret, WriteKey[0] GenKey
            kc = 0x0001 | (4 << 2) | 0x0002 | 0x0020  # Private, P256, PubInfo, Lockable
        else:
            sc, kc = 0x0000, 0x0000
        c[20 + 2 * s], c[21 + 2 * s] = sc & 0xFF, sc >> 8
        c[96 + 2 * s], c[97 + 2 * s] = kc & 0xFF, kc >> 8
    return c


class ATECC:
    def __init__(self, **kw):
        self.awake = False; self.resp = None; self.busy = 0; self.ptr = 0
        self.rev = kw.get("rev", bytes([0, 0, 0x60, 0x03]))
        self.cfg_locked = kw.get("cfg_locked", True); self.data_locked = kw.get("data_locked", True)
        self.present = kw.get("present", True); self.corrupt = kw.get("corrupt", None)
        self.busy_polls = kw.get("busy_polls", 3); self.always_busy = kw.get("always_busy", False)
        self.read_status = kw.get("read_status", 0x0F)      # what a clear-text read of a private slot returns
        self.secret_readable = kw.get("secret_readable", False)
        self.cfg = bytearray(kw.get("cfg", good_config()))
        self.serial = kw.get("serial", bytes([0x01, 0x23, 0xAA, 0xBB, 0, 0, 0, 0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5]))
        self.keys = {}                                       # slot -> EllipticCurvePrivateKey
        self.tempkey = None; self.tempkey_valid = False
        self.wake_nack = 0; self.cmds = []; self.reads = []; self.overread = 0; self.wakes = 0
        self.genkey_fail = False; self.sign_status = None
    def status(self, s): return frame(bytes([s]))
    def _c(self, r): return self.corrupt(r) if self.corrupt else r
    def config(self):
        c = bytearray(self.cfg); c[0:4] = self.serial[0:4]; c[8:13] = self.serial[8:13]
        c[86] = 0x00 if self.data_locked else 0x55; c[87] = 0x00 if self.cfg_locked else 0x55
        return bytes(c)
    def wake_pulse(self, low_us):
        if self.present and low_us >= 60:
            self.awake = True; self.resp = self._c(frame(bytes([0x11]))); self.ptr = 0; self.wakes += 1
            self.tempkey_valid = False
    def write(self, addr, d):
        if not self.present or addr != 0x60 or not self.awake: return -1
        d = bytes(d)
        if d[0] == 0x01: self.awake = False; self.resp = None; self.tempkey_valid = False; return len(d)   # sleep wipes TempKey
        if d[0] == 0x02: return len(d)
        if d[0] != 0x03: return len(d)
        if d[1] != len(d) - 1 or crc16(d[1:-2]) != (d[-2] | d[-1] << 8):
            self.resp = self._c(self.status(0xFF)); self.ptr = 0; self.busy = self.busy_polls; return len(d)
        op, p1, p2, data = d[2], d[3], d[4] | d[5] << 8, d[6:-2]
        self.cmds.append((op, p1, p2, len(data))); self.busy = self.busy_polls
        self.resp = self._c(self.execute(op, p1, p2, data)); self.ptr = 0; return len(d)
    def pub_bytes(self, key):
        n = key.public_key().public_numbers(); return n.x.to_bytes(32, "big") + n.y.to_bytes(32, "big")
    def execute(self, op, p1, p2, data):
        if op == 0x30: return frame(self.rev)
        if op == 0x1B: return frame(os.urandom(32))
        if op == 0x02:                                                         # Read
            zone = p1 & 3; n = 32 if p1 & 0x80 else 4
            if zone == 0:
                off = ((p2 >> 3) & 0x1F) * 32 + (p2 & 7) * 4 if n == 4 else (p2 >> 3 & 0x1F) * 32
                return frame(self.config()[off:off + n])
            if zone == 2:
                slot = (p2 >> 3) & 0xF
                if self.secret_readable: return frame(bytes(32)[:n])
                return self.status(self.read_status)
        if op == 0x16:                                                         # Nonce
            if (p1 & 3) == 3 and len(data) == 32 and p2 == 0:
                self.tempkey = bytes(data); self.tempkey_valid = True; return self.status(0)
            return self.status(0x03)
        if op == 0x40:                                                         # GenKey
            slot = p2 & 0xF
            if p2 >> 4: return self.status(0x03)
            if p1 == 0x04:
                if self.genkey_fail: return self.status(0x0F)
                k = ec.generate_private_key(ec.SECP256R1()); self.keys[slot] = k
                return frame(self.pub_bytes(k))
            if p1 == 0x00:
                if slot not in self.keys: return self.status(0x0F)
                return frame(self.pub_bytes(self.keys[slot]))
            return self.status(0x03)
        if op == 0x41:                                                         # Sign
            slot = p2 & 0xF
            if p1 != 0x80: return self.status(0x03)                            # only EXTERNAL signing is used
            if not self.tempkey_valid: return self.status(0x0F)
            if slot not in self.keys: return self.status(0x0F)
            if self.sign_status is not None: return self.status(self.sign_status)
            der = self.keys[slot].sign(self.tempkey, ec.ECDSA(Prehashed(hashes.SHA256())))
            r, s = decode_dss_signature(der); self.tempkey_valid = False
            return frame(r.to_bytes(32, "big") + s.to_bytes(32, "big"))
        return self.status(0x03)
    def read(self, addr, n):
        if not self.present or addr != 0x60 or not self.awake or self.resp is None or self.always_busy: return -1, b""
        if self.busy > 0: self.busy -= 1; return -1, b""
        if self.wake_nack > 0 and self.ptr == 0 and n == 4 and self.resp[1:2] == b"\x11":
            self.wake_nack -= 1; return -1, b""
        self.reads.append(n)
        if n > len(self.resp) - self.ptr: self.overread += 1
        r = (self.resp[self.ptr:] + b"\xff" * n)[:n]; self.ptr += n; return n, r


class Board:
    def __init__(self, chip):
        self.chip = chip
        self.wr = WR(lambda a, p, n: self.chip.write(a, bytes(p[:n])))
        self.wk = WK(lambda us: self.chip.wake_pulse(us))
        def _rd(a, p, n):
            r, d = self.chip.read(a, n)
            if r > 0:
                for i in range(n): p[i] = d[i]
            return r
        self.rd = RD(_rd)
        lib.set_cbs(self.wr, self.rd, self.wk)


fails = 0
def check(c, msg):
    global fails
    print(("ok   " if c else "FAIL ") + msg); fails += (not c)


def init_with(**kw):
    chip = ATECC(**kw); b = Board(chip); r = lib.se_init(); return chip, b, r


def verify(pub, digest, sig):
    k = ec.EllipticCurvePublicNumbers(int.from_bytes(pub[:32], "big"), int.from_bytes(pub[32:], "big"), ec.SECP256R1()).public_key()
    try:
        k.verify(__import__("cryptography").hazmat.primitives.asymmetric.utils.encode_dss_signature(
            int.from_bytes(sig[:32], "big"), int.from_bytes(sig[32:], "big")), digest, ec.ECDSA(Prehashed(hashes.SHA256())))
        return True
    except InvalidSignature:
        return False


# ---------------------------------------------------------------- se_init: success and every fail-closed path
chip, b, r = init_with(); check(r == 0 and lib.se_active(), "provisioned + locked chip -> SE_OK, driver active")
ch_late = ATECC(); ch_late.wake_nack = 2; Board(ch_late); check(lib.se_init() == 0, "chip slow to answer the wake (2 NACKs) still initialises")
ch_dead = ATECC(); ch_dead.wake_nack = 1000; Board(ch_dead); check(lib.se_init() == 1, "chip that never answers the wake -> error 1, bounded")

def cfg_with(slot, sc=None, kc=None):
    c = good_config()
    if sc is not None: c[20 + 2 * slot], c[21 + 2 * slot] = sc & 0xFF, sc >> 8
    if kc is not None: c[96 + 2 * slot], c[97 + 2 * slot] = kc & 0xFF, kc >> 8
    return bytes(c)

GOOD_SC, GOOD_KC = 0x0381 & ~0x0200, 0x0001 | (4 << 2) | 0x0022
cases = [
    ("no device", dict(present=False), 1),
    ("not an ATECC608 (rev 50 00)", dict(rev=bytes([0, 0, 0x50, 0])), 2),
    ("config zone unlocked", dict(cfg_locked=False), 3),
    ("data zone unlocked", dict(data_locked=False), 3),
    ("attestation slot is not a private key slot", dict(cfg=cfg_with(0, kc=0x0000)), 4),
    ("credential slot is not P-256", dict(cfg=cfg_with(3, kc=0x0001 | (7 << 2))), 4),
    ("credential slot without IsSecret", dict(cfg=cfg_with(2, sc=0x0101)), 4),
    ("credential slot without external-sign permission", dict(cfg=cfg_with(4, sc=0x0180)), 4),
    ("credential slot allows host-written private keys (PrivWrite) - a known key could be injected", dict(cfg=cfg_with(5, sc=0x0381)), 4),
    ("credential slot without GenKey permission", dict(cfg=cfg_with(6, sc=0x0081)), 4),
    ("private slot readable in clear", dict(secret_readable=True), 4),
    ("clear read of a private slot fails with an unexpected status", dict(read_status=0x03), 6),
]
for name, kw, want in cases:
    chip, b, r = init_with(**kw); check(r == want and not lib.se_active(), f"{name} -> error {want}, driver NOT active")
for tag, f in (("bit flip", lambda r: bytes([r[0]]) + bytes([r[1] ^ 1]) + r[2:]), ("truncated", lambda r: r[:2] + b"\xff" * 10),
               ("count byte garbage", lambda r: bytes([0x77]) + r[1:])):
    chip, b, r = init_with(corrupt=f); check(r != 0 and not lib.se_active(), f"corrupted responses ({tag}) -> init refused")

# ---------------------------------------------------------------- operations need an initialised driver
chip = ATECC(); Board(chip); lib.se_init()
x = ctypes.create_string_buffer(32); y = ctypes.create_string_buffer(32); sig = ctypes.create_string_buffer(64)
dig = hashlib.sha256(b"message").digest()

# ---------------------------------------------------------------- GenKey / pubkey / sign
check(lib.se_genkey(1, x, y) == 0, "GenKey creates a private key in slot 1 and returns its public key")
pub1 = x.raw + y.raw
check(pub1 == chip.pub_bytes(chip.keys[1]), "returned public key is the chip key's public key")
check(lib.se_pubkey(1, x, y) == 0 and x.raw + y.raw == pub1, "se_pubkey returns the same public key later")
check(lib.se_sign(1, dig, sig) == 0 and verify(pub1, dig, sig.raw), "se_sign: 64-byte r||s verifies against the slot's public key (real ECDSA P-256)")
check(chip.cmds[-2][0] == 0x16 and chip.cmds[-1][0] == 0x41 and chip.cmds[-1][1] == 0x80, "sign = Nonce(pass-through) then Sign(external), in ONE wake session")
w0 = chip.wakes; lib.se_sign(1, dig, sig); check(chip.wakes == w0 + 1, "one wake per signature (TempKey must survive until Sign)")
dig2 = hashlib.sha256(b"other").digest(); lib.se_sign(1, dig2, sig)
check(not verify(pub1, dig, sig.raw) and verify(pub1, dig2, sig.raw), "signature is bound to the digest that was sent")
check(lib.se_genkey(1, x, y) == 0 and x.raw + y.raw != pub1, "re-keying a slot destroys the old key (new public key)")
check(lib.se_sign(1, dig, sig) == 0 and not verify(pub1, dig, sig.raw), "after re-keying, the OLD public key no longer verifies")
check(lib.se_sign(2, dig, sig) != 0, "signing with a slot that holds no key fails")
chip.genkey_fail = True; check(lib.se_genkey(3, x, y) != 0, "GenKey execution error is reported"); chip.genkey_fail = False
chip.sign_status = 0x0F; check(lib.se_sign(1, dig, sig) != 0, "Sign execution error is reported"); chip.sign_status = None
for bad in (8, 9, 15, 16, 200):
    check(lib.se_genkey(bad, x, y) != 0 and lib.se_sign(bad, dig, sig) != 0 and lib.se_pubkey(bad, x, y) != 0, f"slot {bad} is outside the firmware's slot map -> refused before touching the chip")
n_before = len(chip.cmds); lib.se_genkey(9, x, y); check(len(chip.cmds) == n_before, "...no I2C traffic at all for an out-of-map slot")

# ---------------------------------------------------------------- framing / robustness
chip.reads.clear(); chip.overread = 0
lib.se_genkey(2, x, y); lib.se_sign(2, dig, sig); o = ctypes.create_string_buffer(32); lib.se_random32(o)
check(chip.overread == 0, f"never reads more bytes than an answer holds (over-reads: {chip.overread})")
check(2 in chip.reads and 65 in chip.reads, f"67-byte answers (GenKey/Sign) are read as a 2-byte head + 65 bytes (reads seen: {sorted(set(chip.reads))})")
ser = ctypes.create_string_buffer(9); check(lib.se_serial(ser) == 0 and ser.raw == chip.serial[0:4] + chip.serial[8:13], "serial number = bytes 0..3 + 8..12 of the config zone")
r1 = ctypes.create_string_buffer(32); r2 = ctypes.create_string_buffer(32)
check(lib.se_random32(r1) == 0 and lib.se_random32(r2) == 0 and r1.raw != r2.raw, "random32 returns fresh chip randomness")
chip.corrupt = lambda r: bytes([r[0]]) + bytes([r[1] ^ 1]) + r[2:]
check(lib.se_genkey(2, x, y) != 0 and lib.se_sign(2, dig, sig) != 0 and lib.se_random32(o) != 0, "corrupted answers (CRC) are rejected by every operation")
chip.corrupt = None

# ---------------------------------------------------------------- 6000 hostile rounds: never crash, never accept a wrong signature
random.seed(7); wrong = clean = 0
for i in range(6000):
    kind = random.choice(["flip", "trunc", "garbage", "none", "none", "status"])
    def mk(kind):
        if kind == "flip":
            return lambda r: bytes(b ^ (1 << random.randrange(8)) if random.random() < 0.05 else b for b in r)
        if kind == "trunc": return lambda r: r[:random.randrange(1, len(r) + 1)] + b"\xff" * 80
        if kind == "garbage": return lambda r: os.urandom(len(r))
        if kind == "status": return lambda r: frame(bytes([random.choice([0x01, 0x03, 0x0F, 0xEE, 0xFF])]))
        return None
    chip.corrupt = mk(kind); chip.keys.setdefault(5, ec.generate_private_key(ec.SECP256R1()))
    pubk = chip.pub_bytes(chip.keys[5]); d = os.urandom(32)
    s = ctypes.create_string_buffer(64)
    r = lib.se_sign(5, d, s)
    if r == 0:
        if verify(pubk, d, s.raw): clean += 1
        else: wrong += 1
check(wrong == 0, f"6000 hostile-chip rounds: no crash, 0 wrong signatures reported as success ({clean} clean passes)")
chip.corrupt = None

# ---------------------------------------------------------------- bounded waits
chip2 = ATECC(always_busy=True); Board(chip2); lib.se_init()
chip = ATECC(); Board(chip); lib.se_init(); chip.always_busy = True
check(lib.se_genkey(1, x, y) != 0, "chip stuck busy: operation fails after a bounded wait (no hang)")
print("FAILURES:", fails); sys.exit(1 if fails else 0)
