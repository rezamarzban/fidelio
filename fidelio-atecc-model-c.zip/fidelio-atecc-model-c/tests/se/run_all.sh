#!/bin/bash
# usage: run_all.sh <repo-root>   (gcc with ASan/UBSan, python3 + 'cryptography'; no wolfSSL / pico-sdk needed)
set -e
REPO=$(cd "$1" && pwd); HERE=$(cd "$(dirname "$0")" && pwd); W=$(mktemp -d); cd $W
cp $HERE/*.c $HERE/*.py .; cp -r $HERE/stubs .
echo "== se.c vs. ATECC608 command model (config checks, fail-closed paths, GenKey/Nonce/Sign with real ECDSA, framing, 6000 hostile rounds)"
gcc -w -shared -fPIC -fsanitize=address,undefined -I$W/stubs -I$REPO/src -o libse.so glue.c $REPO/src/se.c
LD_PRELOAD=$(gcc -print-file-name=libasan.so) ASAN_OPTIONS=detect_leaks=0 python3 t_se.py | grep -E "FAIL|FAILURES|ok   6000|ok   provisioned"
echo "== src/rand.c: chip entropy mandatory"
gcc -w -fsanitize=address,undefined -I$W/stubs -I$REPO/src -o rt_se rt_se.c $REPO/src/rand.c && ./rt_se | tail -2
