#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "wolfssl/wolfcrypt/sha256.h"
extern int custom_random_seed(unsigned char*, unsigned int);
#include "hardware/structs/rosc.h"
rosc_hw_t rosc_state, *rosc_hw = &rosc_state;
static uint32_t rs = 12345, tick; static bool g_se; static int se_rc; static uint8_t se_bytes[32]; static int se_calls;
void adc_init(void){} void adc_gpio_init(uint32_t p){(void)p;} void adc_select_input(uint32_t i){(void)i;} void sleep_ms(uint32_t m){(void)m;}
uint16_t adc_read(void){ return 0; }                                   /* dead ADC: worst case */
void busy_wait_us_32(uint32_t u){ (void)u; rs=rs*1664525u+1013904223u; rosc_state.randombit=rs>>31; }
uint32_t time_us_32(void){ return tick += 37; } uint64_t time_us_64(void){ return tick += 37; }
bool se_active(void){ return g_se; } int se_random32(uint8_t*o){ se_calls++; if(se_rc) return se_rc; memcpy(o,se_bytes,32); return 0; }
static uint64_t acc; 
int wc_InitSha256(wc_Sha256*s){acc=1469598103934665603ULL;(void)s;return 0;} int wc_Sha256Update(wc_Sha256*s,const void*d,word32 n){(void)s;const uint8_t*p=d;while(n--){acc^=*p++;acc*=1099511628211ULL;}return 0;}
int wc_Sha256Final(wc_Sha256*s,uint8_t*o){(void)s;uint64_t h=acc;for(int i=0;i<32;i++){h^=h>>13;h*=0x9E3779B97F4A7C15ULL;o[i]=(uint8_t)(h>>(8*(i%8)));}return 0;}
void wc_Sha256Free(wc_Sha256*s){(void)s;}
static int fails;
#define CHECK(c) do{ if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;} else printf("ok   %s\n",#c);}while(0)
int main(void){
  unsigned char a[48], b[48], c[48], buf[64]; int i;
  g_se=false; se_calls=0; memset(buf,0xCC,64); CHECK(custom_random_seed(buf,48)==-1 && se_calls==0);   /* no chip => no seed: RP2040 noise alone is never trusted */
  g_se=true; memset(se_bytes,0x11,32); se_calls=0; se_rc=0; CHECK(custom_random_seed(b,48)==0 && se_calls==1);
  memset(se_bytes,0x22,32); rs=12345; tick=0; custom_random_seed(c,48);
  memset(se_bytes,0x11,32); rs=12345; tick=0; custom_random_seed(a,48);
  CHECK(memcmp(a,c,48)!=0);                                                                  /* chip bytes really influence the seed */
  se_rc=-3; memset(buf,0xCC,64); CHECK(custom_random_seed(buf,48)==-1);                      /* chip failure => seed fails (fail closed) */
  int none=1; (void)none;
  for(i=0;i<16;i++) if(buf[48+i]!=0xCC) fails++;                                             /* no overrun on the error path */
  se_rc=0; for(unsigned n=1;n<=100;n+=7){ unsigned char *p=malloc(n+16); memset(p,0xCC,n+16); int r=custom_random_seed(p,n); int g=1; for(int k=0;k<16;k++) if(p[n+k]!=0xCC) g=0; if(r||!g) fails++; free(p); }
  printf(fails?"FAILURES\n":"rand: chip entropy mandatory and mixed in, fails closed, no overruns\n"); return fails!=0; }
