import subprocess, os, struct, hashlib
CID = bytes([1,2,3,4])
def frames(cmd, data, cid=CID):
    out=[]; first=data[:57]
    out.append(cid+bytes([0x80|cmd])+struct.pack(">H",len(data))+first.ljust(57,b"\0"))
    rest=data[57:]; seq=0
    while rest:
        out.append(cid+bytes([seq])+rest[:59].ljust(59,b"\0")); rest=rest[59:]; seq+=1
    return out
def cont(seq, cid=CID, data=b""): return cid+bytes([seq])+data.ljust(59,b"\0")
def run(exe, flash, frs, button="down", maxsleeps=None, timeout=60):
    env=dict(os.environ, RIG_BUTTON=button)
    if maxsleeps: env["RIG_MAX_SLEEPS"]=str(maxsleeps)
    p=subprocess.run([exe,flash],input=b"".join(frs),capture_output=True,env=env,timeout=timeout)
    raw=p.stdout; rep=[raw[i:i+64] for i in range(0,len(raw)-63,64)]
    return p.returncode, rep, p.stderr.decode(errors="replace")
def assemble(rep):
    """reassemble messages from reply frames -> list of (cmd,payload)"""
    msgs=[]; i=0
    while i<len(rep):
        f=rep[i]; i+=1
        if not (f[4]&0x80): continue
        cmd=f[4]&0x7f; ln=struct.unpack(">H",f[5:7])[0]; data=f[7:7+min(ln,57)]
        while len(data)<ln and i<len(rep):
            data+=rep[i][5:5+min(59,ln-len(data))]; i+=1
        msgs.append((cmd,data))
    return msgs
def apdu(ins,p1,data): return bytes([0,ins,p1,0,0,len(data)>>8&0xff,len(data)&0xff])+data
APP=hashlib.sha256(b"https://example.com").digest(); CH=bytes(range(32))
def new_flash(path):
    if os.path.exists(path): os.remove(path)
