/* TEST DOUBLE of the ATECC608 for the host rig: private keys live ONLY in this file's static
 * table (and the .chip file), never in firmware memory.  Software P-256 here is test scaffolding. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "wolfssl/wolfcrypt/settings.h"
#include "wolfssl/wolfcrypt/ecc.h"
#include "wolfssl/wolfcrypt/random.h"
#include "se.h"
static bool g_on;
static struct { bool valid; uint8_t priv[32]; } K[16];
static char chipfile[512];
static WC_RNG rng; static bool rng_ok;
void se_stub_open(const char *flashpath) {
  snprintf(chipfile, sizeof chipfile, "%s.chip", flashpath ? flashpath : "none");
  memset(K, 0, sizeof K);
  FILE *f = fopen(chipfile, "rb"); if (f) { if (fread(K, sizeof K, 1, f) != 1) memset(K, 0, sizeof K); fclose(f); }
  if (!rng_ok) { wc_InitRng(&rng); rng_ok = true; }
}
static void save(void) { FILE *f = fopen(chipfile, "wb"); if (f) { fwrite(K, sizeof K, 1, f); fclose(f); } }
int se_init(void) { if (getenv("RIG_NOCHIP")) return SE_E_NO_DEVICE; g_on = true; return SE_OK; }
bool se_active(void) { return g_on; }
int se_serial(uint8_t o[SE_SERIAL_LEN]) { const char *e = getenv("RIG_SERIAL"); memset(o, 7, 9); if (e) o[0] = (uint8_t)e[0]; return 0; }
int se_random32(uint8_t o[32]) { return wc_RNG_GenerateBlock(&rng, o, 32); }
static int pub_of(int slot, uint8_t x[32], uint8_t y[32]) {
  ecc_key k; word32 xl = 32, yl = 32; int r;
  if (!K[slot].valid) return -1;
  wc_ecc_init(&k);
  r = wc_ecc_import_private_key_ex(K[slot].priv, 32, NULL, 0, &k, ECC_SECP256R1);
  if (!r) r = wc_ecc_make_pub_ex(&k, NULL, NULL);
  if (!r) r = wc_ecc_export_public_raw(&k, x, &xl, y, &yl);
  wc_ecc_free(&k); return r;
}
int se_pubkey(uint8_t slot, uint8_t x[32], uint8_t y[32]) { if (!g_on || slot > 15) return -1; return pub_of(slot, x, y); }
int se_genkey(uint8_t slot, uint8_t x[32], uint8_t y[32]) {
  ecc_key k; word32 l = 32, xl = 32, yl = 32; int r;
  if (!g_on || slot > 15) return -1;
  if (getenv("RIG_GENKEY_FAIL")) return -1;
  wc_ecc_init(&k); r = wc_ecc_make_key_ex(&rng, 32, &k, ECC_SECP256R1);
  if (!r) r = wc_ecc_export_private_only(&k, K[slot].priv, &l);
  if (!r) r = wc_ecc_export_public_raw(&k, x, &xl, y, &yl);
  wc_ecc_free(&k);
  if (r) return -1; K[slot].valid = true; save(); return 0;
}
static int der_to_raw(const uint8_t *d, size_t n, uint8_t raw[64]) {
  size_t p = 2; if (d[1] & 0x80) p++;
  for (int part = 0; part < 2; part++) {
    size_t l = d[p + 1]; const uint8_t *v = d + p + 2; p += 2 + l;
    while (l > 32) { v++; l--; }
    memset(raw + 32 * part, 0, 32); memcpy(raw + 32 * part + 32 - l, v, l);
  }
  return 0;
}
int se_sign(uint8_t slot, const uint8_t dg[32], uint8_t sig[64]) {
  ecc_key k; byte der[80]; word32 dl = sizeof der; int r;
  if (!g_on || slot > 15 || !K[slot].valid) return -1;
  if (getenv("RIG_SIGN_BAD") ) { memset(sig, 0x11, 64); return 0; }   /* a faulty chip */
  wc_ecc_init(&k); r = wc_ecc_import_private_key_ex(K[slot].priv, 32, NULL, 0, &k, ECC_SECP256R1);
  if (!r) r = wc_ecc_sign_hash(dg, 32, der, &dl, &rng, &k);
  wc_ecc_free(&k); if (r) return -1;
  return der_to_raw(der, dl, sig);
}
