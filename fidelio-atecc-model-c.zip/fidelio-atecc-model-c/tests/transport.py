import sys
sys.path.insert(0, ".")
from drv import *
import os, struct

exe = sys.argv[1]
fl = "./f_tr.bin"
new_flash(fl)
run(exe, fl, [], button="down")
A = bytes([0xA1, 0xA2, 0xA3, 0xA4])
B = bytes([0xB1, 0xB2, 0xB3, 0xB4])
BC = b"\xff\xff\xff\xff"
TICK = b"\xee\xee\xee\xee" + bytes(60)
res = []


def chk(n, ok, info=""):
    res.append((n, bool(ok), info))


def errcode(rep, cid):
    for f in rep:
        if f[:4] == cid and f[4] == 0xBF:
            return f[7]
    return None


n1 = bytes(range(8))
n2 = bytes(range(8, 16))

# 1 broadcast INIT
rc, rep, _ = run(exe, fl, frames(0x06, n1, cid=BC) + frames(0x06, n2, cid=BC))
c1 = rep[0][15:19]
c2 = rep[1][15:19]
chk("broadcast INIT: nonce echoed", rep[0][7:15] == n1 and rep[1][7:15] == n2)
chk("broadcast INIT: distinct, non-zero, non-broadcast channels",
    c1 != c2 and c1 != bytes(4) and c1 != BC and c2 != BC, "%s %s" % (c1.hex(), c2.hex()))
chk("INIT reply frame is zero padded", not any(rep[0][24:]))

# 2 PING echo, multi-frame, reply frames carry the CID
data = os.urandom(200)
rc, rep, _ = run(exe, fl, frames(0x01, data, cid=A))
m = assemble(rep)
chk("PING echoes 200 bytes (multi-frame)", m and m[0][0] == 1 and m[0][1] == data)
chk("every reply frame (incl. continuation) carries the request CID",
    len(rep) > 1 and all(f[:4] == A for f in rep), "frames=%d" % len(rep))

# 3 foreign continuation not spliced in
fr = frames(0x01, data, cid=A)
evil = cont(0, cid=B, data=b"\x66" * 59)
rc, rep, _ = run(exe, fl, [fr[0], evil] + fr[1:])
mA = assemble([f for f in rep if f[:4] == A])
chk("foreign-channel continuation not spliced into the message", mA and mA[0][1] == data)
chk("...and the intruder is told CHANNEL_BUSY", errcode(rep, B) == 0x06)

# 4 foreign command mid-transfer
rc, rep, _ = run(exe, fl, [fr[0]] + frames(0x01, b"x", cid=B) + frames(0x06, n1, cid=BC) + fr[1:])
mA = assemble([f for f in rep if f[:4] == A])
chk("foreign command mid-transfer -> CHANNEL_BUSY", errcode(rep, B) == 0x06)
chk("in-flight message survives the foreign command", mA and mA[0][1] == data)
chk("broadcast INIT answered during a transfer", any(f[:4] == BC and f[4] == 0x86 for f in rep))

# 5 wrong sequence
rc, rep, _ = run(exe, fl, [fr[0], cont(5, cid=A)])
chk("bad sequence -> INVALID_SEQ (0x04)", errcode(rep, A) == 0x04)

# 6 stall timeout
rc, rep, _ = run(exe, fl, [fr[0], TICK, fr[1]])
chk("stalled message -> MSG_TIMEOUT (0x05)", errcode(rep, A) == 0x05, str(errcode(rep, A)))
rc, rep, _ = run(exe, fl, [fr[0], TICK] + frames(0x01, b"hi", cid=B))
mB = assemble([f for f in rep if f[:4] == B])
chk("after a stall, another channel is served", mB and mB[0][1] == b"hi")

# 7 reserved cid, bad lengths
rc, rep, _ = run(exe, fl, frames(0x06, n1, cid=bytes(4)))
chk("channel 0 ignored (no reply)", len(rep) == 0)
rc, rep, _ = run(exe, fl, frames(0x06, b"123", cid=A))
chk("INIT with len!=8 -> INVALID_LEN", errcode(rep, A) == 0x03)
big = A + bytes([0x81]) + struct.pack(">H", 8000) + bytes(57)
rc, rep, _ = run(exe, fl, [big])
chk("length > max -> INVALID_LEN", errcode(rep, A) == 0x03)

# 8 WINK / CANCEL
rc, rep, _ = run(exe, fl, frames(0x08, b"", cid=A))
m = assemble(rep)
chk("WINK answered with empty payload", m and m[0][0] == 8 and len(m[0][1]) == 0)
rc, rep, _ = run(exe, fl, frames(0x11, b"", cid=A))
chk("CANCEL: no reply", len(rep) == 0)

# 9 U2F on an allocated channel
rc, rep, _ = run(exe, fl, frames(0x06, n1, cid=BC))
newc = rep[0][15:19]
rc, rep, _ = run(exe, fl, frames(0x03, apdu(3, 0, b""), cid=newc))
m = assemble(rep)
chk("U2F VERSION on allocated channel", m and m[0][1][:6] == b"U2F_V2")

print("=== TRANSPORT ===")
for n, ok, i in res:
    print(("PASS " if ok else "FAIL ") + n + (("   [" + i + "]") if i else ""))
