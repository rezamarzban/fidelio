Host tests (x86 Linux). They compile the REAL src/u2f.c, ctap2.c, cred_store.c, att_cert.c, att_der.c, hw_sign.c + wolfCrypt
against stubbed pico-sdk/TinyUSB headers and a TEST DOUBLE of the chip (se_on.c: private keys exist only in that file's table and a
.chip file, software P-256 there is test scaffolding). They simulate flash (writing a non-erased cell aborts) and the button.

  build.sh <repo-root> <out> [flags]   add -fsanitize=address,undefined -fno-sanitize=shift for the sanitizer build
  hwtests.py   <bin>                   MODEL C invariants (23): no private key anywhere in flash, per-credential slots, slot exhaustion,
                                       reset destroys keys in the chip, no chip / wrong chip -> refuses, faulty signature never released,
                                       corrupted newest table -> previous table, legacy key erased, counter monotonic
  attacks.py <bin> <flash> <tag>       raw-protocol attack checks (12)        func.py <bin> <flash> <tag>   python-fido2 U2F/CTAP2/PIN (24)
  transport.py <bin>                   CTAPHID channel isolation etc. (19)    fuzz.py <bin> <n> [seed]      CTAP2 fuzzing (sanitizer build)
  wrap.py <bin>                        CBOR length wrap-around exploit
  se/run_all.sh <repo-root>            driver vs. ATECC608 command model + RNG test (see se/)

Test env knobs of the rig: RIG_NOCHIP, RIG_SERIAL, RIG_SIGN_BAD (chip returns a bad signature), RIG_GENKEY_FAIL.
NOT covered: real USB, real flash timing, a REAL ATECC608, real entropy, the physical button, physical attacks.
