#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#define __not_in_flash_func(x) x
#define PICO_DEFAULT_LED_PIN 25
#define GPIO_OUT 1
#define GPIO_IN 0
void sleep_ms(uint32_t ms);
static inline void tight_loop_contents(void){}
uint64_t time_us_64(void);
static inline uint32_t time_us_32(void){return (uint32_t)time_us_64();}
