#pragma once
#include "hid.h"
int tud_hid_report(uint8_t id,const void*r,uint16_t len);
