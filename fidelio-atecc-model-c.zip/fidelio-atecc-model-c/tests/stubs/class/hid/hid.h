#pragma once
#include <stdint.h>
typedef int hid_report_type_t;
