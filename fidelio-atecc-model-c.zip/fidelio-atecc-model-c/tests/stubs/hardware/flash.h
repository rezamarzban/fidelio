#pragma once
#include <stdint.h>
extern uint8_t fake_flash[];
#define XIP_BASE ((uintptr_t)fake_flash)
#define FLASH_SECTOR_SIZE 4096
#define FLASH_PAGE_SIZE 256
void flash_range_erase(uint32_t off, uint32_t cnt);
void flash_range_program(uint32_t off, const uint8_t *d, uint32_t cnt);
