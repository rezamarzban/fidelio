#pragma once
#include <stdint.h>
#define GPIO_OUT 1
#define GPIO_IN 0
void gpio_put(uint32_t p, int v);
int gpio_get(uint32_t p);
static inline void gpio_init(uint32_t p){(void)p;}
static inline void gpio_set_dir(uint32_t p,int d){(void)p;(void)d;}
static inline void gpio_pull_up(uint32_t p){(void)p;}
