#pragma once
void rig_reboot(void);
static inline void watchdog_reboot(int a,int b,int c){(void)a;(void)b;(void)c;rig_reboot();}
