import ctypes, hashlib, hmac, os, random, sys

lib = ctypes.CDLL("./libse.so")
WR = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_uint8, ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t)
RD = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_uint8, ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t)
PG = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_uint32)
PP = ctypes.CFUNCTYPE(None, ctypes.c_uint32, ctypes.c_int)
HM = ctypes.CFUNCTYPE(None, ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t, ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t, ctypes.POINTER(ctypes.c_uint8))
WK = ctypes.CFUNCTYPE(None, ctypes.c_uint64)
lib.set_cbs.argtypes = [WR, RD, PG, PP, HM, WK]
lib.se_init.restype = ctypes.c_int; lib.se_active.restype = ctypes.c_bool; lib.se_jumper_present.restype = ctypes.c_bool
lib.se_random32.argtypes = [ctypes.c_char_p]; lib.se_hmac.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p]
lib.se_serial.argtypes = [ctypes.c_char_p]

def crc16(data):
    crc = 0
    for b in data:
        m = 1
        while m < 256:
            bit = 1 if (b & m) else 0; top = crc >> 15; crc = (crc << 1) & 0xFFFF
            if bit != top: crc ^= 0x8005
            m <<= 1
    return crc
def frame(payload):               # count + payload + crc
    body = bytes([len(payload) + 3]) + payload
    c = crc16(body); return body + bytes([c & 0xFF, c >> 8])

class ATECC:
    """Behavioural model of the ATECC608 command protocol (datasheet framing, CRC, wake/sleep, busy NACK)."""
    def __init__(self, slot_key=None, **kw):
        self.slot_key = slot_key if slot_key is not None else os.urandom(32)
        self.awake = False; self.resp = None; self.busy = 0
        self.rev = kw.get("rev", bytes([0, 0, 0x60, 0x03])); self.cfg_locked = kw.get("cfg_locked", True)
        self.data_locked = kw.get("data_locked", True); self.secret_readable = kw.get("secret_readable", False)
        self.present = kw.get("present", True); self.corrupt = kw.get("corrupt", None)   # fn(bytes)->bytes
        self.busy_polls = kw.get("busy_polls", 3); self.always_busy = kw.get("always_busy", False)
        self.read_status = kw.get("read_status", 0x0F)
        self.serial = kw.get("serial", bytes([0x01, 0x23, 0xAA, 0xBB, 0, 0, 0, 0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5]) )
        self.sha_slot = None; self.sha_buf = b""; self.cmds = []; self.wakes = 0; self.pulses = []; self.ptr = 0; self.max_read = 0; self.overread = 0; self.reads = []; self.wake_nack = 0
    def status(self, s): return frame(bytes([s]))
    def _c(self, r): return self.corrupt(r) if self.corrupt else r
    def config(self):
        c = bytearray(128); c[0:4] = self.serial[0:4]; c[8:13] = self.serial[8:13]
        c[86] = 0x00 if self.data_locked else 0x55; c[87] = 0x00 if self.cfg_locked else 0x55
        return bytes(c)
    def wake_pulse(self, low_us):
        self.pulses.append(low_us)
        if self.present and low_us >= 60:        # datasheet: SDA low >= 60 us
            self.awake = True; self.resp = self._c(frame(bytes([0x11]))); self.ptr = 0; self.wakes += 1; self.sha_slot = None; self.sha_buf = b""
    def write(self, addr, d):
        if not self.present: return -1
        d = bytes(d)
        if addr == 0x00: return -1               # reserved address: the driver must never use it
        if addr != 0x60: return -1
        if not self.awake: return -1          # asleep: NACK
        if d[0] == 0x01: self.awake = False; self.resp = None; self.sha_slot = None; self.sha_buf = b""; return len(d)
        if d[0] == 0x02: return len(d)
        if d[0] != 0x03: return len(d)
        cnt = d[1]
        if cnt != len(d) - 1 or crc16(d[1:-2]) != (d[-2] | d[-1] << 8): self.resp = self._c(self.status(0xFF)); self.ptr = 0; self.busy = self.busy_polls; return len(d)
        op, p1, p2, data = d[2], d[3], d[4] | d[5] << 8, d[6:-2]
        self.cmds.append((op, p1, p2, len(data))); self.busy = self.busy_polls
        self.resp = self._c(self.execute(op, p1, p2, data)); self.ptr = 0; return len(d)
    def execute(self, op, p1, p2, data):
        if op == 0x30: return frame(self.rev)
        if op == 0x1B: return frame(os.urandom(32))
        if op == 0x02:
            zone = p1 & 3; n = 32 if p1 & 0x80 else 4
            if zone == 0:
                off = ((p2 >> 3) & 0x1F) * 32 + (p2 & 7) * 4; return frame(self.config()[off:off + n])
            if zone == 2:
                if self.secret_readable: return frame((self.slot_key if (p2 >> 3) & 0xF == 0 else bytes(32))[:n])
                return self.status(self.read_status)
        if op == 0x47:
            mode = p1 & 7
            if mode == 4:
                if p2 != 0: return self.status(0x0F)
                self.sha_slot = p2; self.sha_buf = b""; return self.status(0)
            if self.sha_slot is None: return self.status(0x0F)
            if mode == 1:
                if p2 != 64 or len(data) != 64: return self.status(0x03)
                self.sha_buf += data; return self.status(0)
            if mode == 5: return self.status(0x03)                 # ATSHA204A/508A code: illegal on the 608 (calib uses 0x02)
            if mode == 2:
                if p2 > 63 or len(data) != p2: return self.status(0x03)
                msg = self.sha_buf + data; self.sha_slot = None
                return frame(hmac.new(self.slot_key, msg, hashlib.sha256).digest())
        return self.status(0x03)
    def read(self, addr, n):
        if not self.present or addr != 0x60: return -1, b""
        if not self.awake or self.resp is None: return -1, b""
        if self.always_busy: return -1, b""
        if self.busy > 0: self.busy -= 1; return -1, b""
        if self.wake_nack > 0 and self.resp is not None and self.ptr == 0 and n == 4 and self.resp[1:2] == b"\x11":
            self.wake_nack -= 1; return -1, b""        # chip slow to answer right after the wake pulse
        self.max_read = max(self.max_read, n); self.reads.append(n)
        if n > len(self.resp) - self.ptr: self.overread += 1      # asked for more bytes than the answer holds
        r = (self.resp[self.ptr:] + b"\xff" * n)[:n]; self.ptr += n; return n, r

class Board:
    def __init__(self, chip, jumper="connected"):
        self.chip = chip; self.jumper = jumper; self.drive = 0
        self.wr = WR(self._wr); self.rd = RD(self._rd); self.pg = PG(self._pg); self.pp = PP(self._pp); self.hm = HM(self._hm); self.wk = WK(self._wk)
        lib.set_cbs(self.wr, self.rd, self.pg, self.pp, self.hm, self.wk)
    def _wr(self, a, p, n): return self.chip.write(a, bytes(p[:n]))
    def _wk(self, low_us): self.chip.wake_pulse(low_us)
    def _rd(self, a, p, n):
        r, d = self.chip.read(a, n)
        if r > 0:
            for i in range(n): p[i] = d[i]
        return r
    def _pg(self, pin):                      # sense pin (6)
        if self.jumper == "connected": return self.drive
        if self.jumper == "open": return 1                       # pull-up
        if self.jumper == "stuck_low": return 0
        if self.jumper == "stuck_high": return 1
    def _pp(self, pin, v):
        if pin == 7: self.drive = v
    def _hm(self, k, kl, m, ml, out):
        d = hmac.new(bytes(k[:kl]), bytes(m[:ml]), hashlib.sha256).digest()
        for i in range(32): out[i] = d[i]

fails = 0
def check(c, msg):
    global fails
    print(("ok   " if c else "FAIL ") + msg); fails += (not c)
def init_with(**kw):
    chip = ATECC(**kw.pop("chip_kw", {})); b = Board(chip, **kw); return chip, b, lib.se_init()

# ---- jumper detection --------------------------------------------------
for j, want in (("connected", True), ("open", False), ("stuck_low", False), ("stuck_high", False)):
    b = Board(ATECC(), jumper=j); check(lib.se_jumper_present() == want, f"jumper '{j}' -> present={want}")

# ---- se_init: success and every fail-closed path ------------------------
chip, b, r = init_with(); check(r == 0 and lib.se_active(), "healthy locked chip -> SE_OK, SE mode active")
# ---- slow wake answer: the reference HAL retries; so must we (bounded) -------------------
ch_late = ATECC(); ch_late.wake_nack = 2; b_late = Board(ch_late); r_late = lib.se_init()
check(r_late == 0, "chip that NACKs the first 2 wake-answer reads still initialises (retry like Microchip hal_i2c_wake)")
ch_dead = ATECC(); ch_dead.wake_nack = 1000; b_dead = Board(ch_dead); r_dead = lib.se_init()
check(r_dead == 1, f"chip that never answers the wake -> error 1, bounded (got {r_dead})")

cases = [("no device", dict(present=False), 1), ("not an ATECC608 (rev 50 00)", dict(rev=bytes([0, 0, 0x50, 0])), 2),
         ("config zone unlocked", dict(cfg_locked=False), 3), ("data zone unlocked", dict(data_locked=False), 3),
         ("secret slot readable in clear", dict(secret_readable=True), 4), ("blank slot (all 0x00)", dict(slot_key=bytes(32)), 5),
         ("blank slot (all 0xFF)", dict(slot_key=b"\xff" * 32), 5), ("read returns unexpected status 0x03", dict(read_status=0x03), 6)]
for name, kw, want in cases:
    chip, b, r = init_with(chip_kw=kw); check(r == want and not lib.se_active(), f"{name} -> error {want}, SE mode NOT active")
for tag, f in (("bit flip", lambda r: bytes([r[0]]) + bytes([r[1] ^ 1]) + r[2:]), ("truncated", lambda r: r[:2] + b"\xff" * 10),
               ("count byte garbage", lambda r: bytes([0x77]) + r[1:])):
    chip, b, r = init_with(chip_kw=dict(corrupt=f)); check(r != 0 and not lib.se_active(), f"corrupted responses ({tag}) -> init refused")

# ---- se_hmac equals HMAC-SHA256(slot key, msg) for all block boundaries -
key = os.urandom(32); chip, b, r = init_with(chip_kw=dict(slot_key=key)); assert r == 0
allok = True
for n in (0, 1, 31, 32, 63, 64, 65, 96, 127, 128, 129, 200):
    m = os.urandom(n); out = ctypes.create_string_buffer(32)
    rc = lib.se_hmac(m, n, out); allok &= (rc == 0 and out.raw == hmac.new(key, m, hashlib.sha256).digest())
check(allok, "se_hmac == HMAC-SHA256(slot key, msg) for lengths 0..200 (block boundaries 63/64/65/127/128)")
chip.cmds.clear(); out = ctypes.create_string_buffer(32); lib.se_hmac(b"x" * 96, 96, out)
check([c[:3] for c in chip.cmds] == [(0x47, 4, 0), (0x47, 1, 64), (0x47, 2, 32)], "96-byte message = HMAC_START(0x04), UPDATE(0x01,64), HMAC_END(0x02,32) as in cryptoauthlib for the 608")
check(all(p >= 60 for p in chip.pulses) and len(chip.pulses) > 0, f"every wake pulse holds SDA low >= 60 us (min seen {min(chip.pulses)} us)")
w0 = chip.wakes; lib.se_hmac(b"a", 1, out); lib.se_hmac(b"b", 1, out)
check(chip.wakes == w0 + 2 and not chip.awake, "chip is woken for each operation and put back to sleep")
chip.awake = False; chip.sha_slot = None
check(lib.se_hmac(b"abc", 3, out) == 0, "operation works even if the chip fell asleep on its own (watchdog)")

# ---- read framing: count byte first, then exactly count-1 bytes ------------
chip.max_read = 0; chip.cmds.clear(); out = ctypes.create_string_buffer(32)
check(lib.se_hmac(b"q" * 40, 40, out) == 0, "hmac still correct with two-phase reads")
check(chip.overread == 0, f"driver never asks for more bytes than the answer holds (over-reads: {chip.overread})")
chip.reads.clear(); o32 = ctypes.create_string_buffer(32); lib.se_random32(o32)
rd = [n for n in chip.reads if n != 4]            # ignore the 4-byte wake answer
check(rd == [2, 33], f"a 35-byte answer is read as 2-byte head + 33 bytes, like Microchip hal_i2c_receive (reads: {chip.reads})")
chip2, b2, r2 = init_with()
check(r2 == 0 and chip2.overread == 0, f"full se_init() sequence (incl. the 4-byte read-refused status) has no over-read (over-reads: {chip2.overread})")
b = Board(chip)          # re-bind the simulated bus to the original chip for the checks below

# ---- random + serial -----------------------------------------------------
o1 = ctypes.create_string_buffer(32); o2 = ctypes.create_string_buffer(32)
check(lib.se_random32(o1) == 0 and lib.se_random32(o2) == 0 and o1.raw != o2.raw and o1.raw != bytes(32), "se_random32 returns 32 fresh bytes")
s = ctypes.create_string_buffer(9); check(lib.se_serial(s) == 0 and s.raw == chip.serial[0:4] + chip.serial[8:13], "se_serial = SN[0..3] || SN[4..8] from config zone")

# ---- failures after init never succeed silently --------------------------
chip.always_busy = True; before = None
rc = lib.se_hmac(b"m" * 10, 10, out); check(rc != 0, "chip stuck busy -> error, bounded (no hang)")
chip.always_busy = False; chip.present = False
check(lib.se_hmac(b"m", 1, out) != 0 and lib.se_random32(o1) != 0 and lib.se_serial(s) != 0, "chip removed after init -> every call fails")
chip.present = True; chip.corrupt = lambda r: bytes([r[0]]) + bytes([r[1] ^ 0x80]) + r[2:]
check(lib.se_hmac(b"m", 1, out) != 0 and lib.se_random32(o1) != 0, "corrupted answers after init -> every call fails (never returns bad data as success)")
lib.se_init()  # reset state for next section

# ---- fuzz: hostile chip. Never crash, never return success with wrong data
random.seed(7); key = os.urandom(32)
chip, b, r = init_with(chip_kw=dict(slot_key=key)); assert r == 0
bad = 0; succ = 0
for i in range(6000):
    mode = random.randrange(5); msg = os.urandom(random.choice((0, 1, 33, 64, 96)))
    def corrupt(r, mode=mode):
        r = bytearray(r)
        if mode == 0: r[random.randrange(len(r))] ^= 1 << random.randrange(8)
        elif mode == 1: r = bytearray(os.urandom(len(r)))
        elif mode == 2: r[0] = random.randrange(256)
        elif mode == 3: r = r[:random.randrange(len(r))] + bytearray(b"\xff" * 80)
        else: pass
        return bytes(r)
    chip.corrupt = corrupt
    out = ctypes.create_string_buffer(32); rc = lib.se_hmac(msg, len(msg), out)
    if rc == 0:
        succ += 1
        if out.raw != hmac.new(key, msg, hashlib.sha256).digest(): bad += 1
    rn = ctypes.create_string_buffer(32); lib.se_random32(rn)
check(bad == 0, f"6000 hostile-chip rounds under ASan/UBSan: no crash, 0 wrong results accepted ({succ} clean passes)")
print("FAILURES:", fails); sys.exit(1 if fails else 0)
