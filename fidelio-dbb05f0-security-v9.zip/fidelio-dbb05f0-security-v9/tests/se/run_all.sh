#!/bin/bash
# usage: run_all.sh <patched-repo-root>      (needs gcc with ASan/UBSan and python3; no wolfSSL / pico-sdk)
set -e
REPO=$(cd "$1" && pwd); HERE=$(cd "$(dirname "$0")" && pwd); W=$(mktemp -d); cd $W
cp $HERE/*.c $HERE/*.py .; cp -r $HERE/stubs .
echo "== ATECC608 protocol: driver vs. simulated chip (jumper, fail-closed paths, HMAC, framing, 6000 hostile rounds)"
gcc -w -shared -fPIC -fsanitize=address,undefined -I$W/stubs -I$REPO/src -o libse.so glue.c $REPO/src/se.c
LD_PRELOAD=$(gcc -print-file-name=libasan.so) ASAN_OPTIONS=detect_leaks=0 python3 t_se.py | tail -40
echo "== real device_kdf / chip binding / enrolment / counter / reset code lifted from src/u2f.c"
python3 extract_parts.py $REPO && gcc -w -fsanitize=address,undefined -I. -o t_int t_int.c && ./t_int | tail -6
echo "== real src/rand.c: chip entropy mixed in, fail closed"
gcc -w -fsanitize=address,undefined -I$W/stubs -I$REPO/src -o rt_se rt_se.c $REPO/src/rand.c && ./rt_se | tail -3
