#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <stdlib.h>
#define FLASH_PAGE_SIZE 256
#define FLASH_SECTOR_SIZE 4096
#define __not_in_flash_func(x) x
#define U2F_LED 25
#define PRESENCE_BUTTON 15
#define ECC_SZ 32
#define SHA256 2
#define FLASH_CTR_ADDR0_OFF 0x70000
#define FLASH_CTR_ADDR1_OFF 0x71000
#define FLASH_MKEY_OFF 0x72000
#define FLASH_MKEY_OFF 0x72000
#define FLASH_MKEY_OFF 0x72000
#define SE_E_COMM 6
#define SE_E_CHIP_CHANGED 7
#define SE_OK 0
#define SE_SERIAL_LEN 9
typedef uint32_t word32; typedef struct { int x; } WC_RNG; typedef struct { int x; } Hmac;
static uint8_t fake_xip[0x200000]; 
#define XIP_BASE ((uintptr_t)fake_xip)
#define FLASH_CTR0 *((uint32_t *)(XIP_BASE + FLASH_CTR_ADDR0_OFF))
#define FLASH_CTR1 *((uint32_t *)(XIP_BASE + FLASH_CTR_ADDR1_OFF))
#define FLASH_CTR0 *((uint32_t *)(XIP_BASE + FLASH_CTR_ADDR0_OFF))
#define FLASH_CTR1 *((uint32_t *)(XIP_BASE + FLASH_CTR_ADDR1_OFF))
#define FLASH_CTR0 *((uint32_t *)(XIP_BASE + FLASH_CTR_ADDR0_OFF))
#define FLASH_CTR1 *((uint32_t *)(XIP_BASE + FLASH_CTR_ADDR1_OFF))
/* ---- mocks ---- */
static bool g_se; static int se_hmac_rc, se_serial_rc, rng_rc; static uint8_t se_serial_val[9]; static uint8_t last_se_msg[200]; static size_t last_se_len;
static uint8_t se_out_val[32];
bool se_active(void){ return g_se; }
int se_hmac(const uint8_t*m,size_t n,uint8_t*o){ memcpy(last_se_msg,m,n); last_se_len=n; if(se_hmac_rc) return se_hmac_rc; memcpy(o,se_out_val,32); return 0; }
int se_serial(uint8_t*o){ if(se_serial_rc) return se_serial_rc; memcpy(o,se_serial_val,9); return 0; }
static uint8_t sw_key[32]; static uint8_t hbuf[256]; static size_t hlen; static int sw_calls;
int wc_HmacInit(Hmac*h,void*a,int b){(void)h;(void)a;(void)b;hlen=0;return 0;}
int wc_HmacSetKey(Hmac*h,int t,const uint8_t*k,word32 n){(void)h;(void)t;memcpy(sw_key,k,n);sw_calls++;return 0;}
int wc_HmacUpdate(Hmac*h,const uint8_t*d,word32 n){(void)h;memcpy(hbuf+hlen,d,n);hlen+=n;return 0;}
int wc_HmacFinal(Hmac*h,uint8_t*o){(void)h;memset(o,0x5C,32);return 0;}   /* marker: "software HMAC ran" */
void wc_HmacFree(Hmac*h){(void)h;}
void ForceZero(void*p,word32 n){volatile uint8_t*q=p;while(n--)*q++=0;}
int wc_InitRng(WC_RNG*r){(void)r;return rng_rc;} int wc_FreeRng(WC_RNG*r){(void)r;return 0;}
int wc_RNG_GenerateBlock(WC_RNG*r,uint8_t*o,word32 n){(void)r;for(word32 i=0;i<n;i++)o[i]=(uint8_t)(i*11+3);return 0;}
static jmp_buf out; static int blink, erased_secret, progs; static uint32_t secret_off=0x75000; static uint8_t written_page[256]; static uint32_t written_off;
void gpio_put(uint32_t p,int v){(void)p;(void)v; if(++blink>30) longjmp(out,1);} int gpio_get(uint32_t p){(void)p;return 0;}
void sleep_ms(uint32_t m){(void)m;} void tight_loop_contents(void){}
void watchdog_reboot(uint32_t a,uint32_t b,uint32_t c){(void)a;(void)b;(void)c;longjmp(out,2);}
static uint32_t erase_log[16]; static int erase_n; static uint32_t ctr_written; static int ctr_writes;
void flash_range_erase(uint32_t o,size_t n){(void)n; if(o==secret_off) erased_secret++; if(erase_n<16) erase_log[erase_n++]=o;}
void flash_range_program(uint32_t o,const uint8_t*d,size_t n){(void)n; progs++; if(o==secret_off){memcpy(written_page,d,256);written_off=o;}}
static uint8_t *device_secret = (uint8_t*)0; static uint32_t U2F_Counter; static uint32_t master_magic = 0xF1D091C0;
static void write_counter_page(uint32_t o,uint32_t c){(void)o; ctr_written=c; ctr_writes++;}
#include "parts.h"
static int fails;
#define CHECK(c) do{ if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);fails++;} else printf("ok   %s\n",#c);}while(0)
int main(void){
  uint8_t a[32], b[32], o[32]; int i;
  for(i=0;i<32;i++){a[i]=i;b[i]=100+i;se_out_val[i]=0xE0+i/8;}
  uint8_t master[32]; memset(master,0x11,32); device_secret = master;
  /* software mode: HMAC(master, a||b), exactly as before */
  g_se=false; sw_calls=0; memset(o,0,32);
  CHECK(device_kdf(a,32,b,32,o)==0); CHECK(sw_calls==1 && hlen==64 && !memcmp(hbuf,a,32) && !memcmp(hbuf+32,b,32) && !memcmp(sw_key,master,32) && o[0]==0x5C);
  /* SE mode: the CHIP computes it over salt||a||b; software HMAC is NOT used */
  uint8_t salt[32]; memset(salt,0x77,32); device_secret=salt; g_se=true; sw_calls=0; se_hmac_rc=0;
  CHECK(device_kdf(a,32,b,32,o)==0); CHECK(sw_calls==0); CHECK(last_se_len==96 && !memcmp(last_se_msg,salt,32) && !memcmp(last_se_msg+32,a,32) && !memcmp(last_se_msg+64,b,32));
  CHECK(!memcmp(o,se_out_val,32));
  CHECK(device_kdf(a,32,b,33,o)!=0);                       /* a+b > 64 bytes rejected (stack buffer cannot overflow) */
  se_hmac_rc=-5; memset(o,0,32); CHECK(device_kdf(a,32,b,32,o)==-5);   /* chip error propagates, never falls back to software */
  CHECK(sw_calls==0); se_hmac_rc=0;
  /* chip binding */
  device_secret=salt; secret_off=0x75000; memset(fake_xip,0xFF,sizeof fake_xip);
  uint8_t serial[9]={1,2,3,4,5,6,7,8,9}; memcpy(se_serial_val,serial,9); memcpy(fake_xip+0x75000+36,serial,9);
  se_serial_rc=0; CHECK(device_se_check()==SE_OK);
  se_serial_val[4]^=1; CHECK(device_se_check()==SE_E_CHIP_CHANGED); se_serial_val[4]^=1;
  se_serial_rc=-1; CHECK(device_se_check()==SE_E_COMM); se_serial_rc=0;
  /* first-boot enrolment in SE mode stores the serial; software mode stores none */
  g_se=true; blink=0; progs=0; erased_secret=0; memset(written_page,0,256); rng_rc=0;
  CHECK(setjmp(out)==0 ? (flash_master_keygen(),0) : 1);      /* ends in watchdog_reboot -> longjmp(...,2) */
  CHECK(erased_secret>=1 && progs>=1 && !memcmp(written_page+36,serial,9) && *(uint32_t*)written_page==master_magic);
  /* chip unreadable during enrolment -> nothing written, blinks forever */
  blink=0; progs=0; erased_secret=0; se_serial_rc=-1; int j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==1 && progs==0 && erased_secret==0); se_serial_rc=0;
  /* software mode enrolment: no serial bytes written (stay 0xFF) */
  g_se=false; secret_off=0x72000; blink=0; progs=0; memset(written_page,0,256); j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && written_off==0x72000 && written_page[36]==0xFF && written_page[44]==0xFF);
  /* reset-time rotation keeps the enrolled serial in SE mode */
  g_se=true; secret_off=0x75000; memcpy(fake_xip+0x75000+36,serial,9); memset(written_page,0,256); written_off=0;
  CHECK(device_rotate_secret()==0 && written_off==0x75000 && !memcmp(written_page+36,serial,9));

  /* ---- U2F counter must never go backwards when the identity changes ---- */
  g_se=true; secret_off=0x75000; blink=0; progs=0; ctr_writes=0; ctr_written=0xDEAD; erase_n=0;
  memset(fake_xip+FLASH_CTR_ADDR0_OFF,0xFF,8192); *(uint32_t*)(fake_xip+FLASH_CTR_ADDR0_OFF)=1234;   /* software mode counted up to 1234 */
  j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && ctr_writes==1 && ctr_written==1234);                  /* SE enrolment keeps the counter */
  memset(fake_xip+FLASH_CTR_ADDR0_OFF,0xFF,8192); *(uint32_t*)(fake_xip+FLASH_CTR_ADDR1_OFF)=77; *(uint32_t*)(fake_xip+FLASH_CTR_ADDR0_OFF)=76;
  ctr_writes=0; j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && ctr_written==77);                                     /* picks the newer of the two sectors */
  memset(fake_xip+FLASH_CTR_ADDR0_OFF,0xFF,8192); g_se=false; secret_off=0x72000; ctr_writes=0;
  j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && ctr_written==0);                                      /* virgin flash: still starts at 0 */

  /* ---- SE enrolment destroys the software master key; software enrolment does not touch the SE salt ---- */
  g_se=true; secret_off=0x75000; erase_n=0; j=setjmp(out); if(j==0) flash_master_keygen();
  { int sw=0, salt=0; for(int k=0;k<erase_n;k++){ if(erase_log[k]==FLASH_MKEY_OFF) sw++; if(erase_log[k]==0x75000) salt++; }
    CHECK(j==2 && sw==1 && salt==1); }
  g_se=false; secret_off=0x72000; erase_n=0; j=setjmp(out); if(j==0) flash_master_keygen();
  { int sw=0, salt=0; for(int k=0;k<erase_n;k++){ if(erase_log[k]==FLASH_MKEY_OFF) sw++; if(erase_log[k]==0x75000) salt++; }
    CHECK(j==2 && sw==1 && salt==0); }                                /* software keygen erases only its own sector */
  /* chip unreadable during SE enrolment: the software key must NOT be destroyed */
  g_se=true; secret_off=0x75000; se_serial_rc=-1; erase_n=0; blink=0; j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==1 && erase_n==0); se_serial_rc=0;

  /* ---- U2F counter must never go backwards when the identity changes ---- */
  g_se=true; secret_off=0x75000; blink=0; progs=0; ctr_writes=0; ctr_written=0xDEAD; erase_n=0;
  memset(fake_xip+FLASH_CTR_ADDR0_OFF,0xFF,8192); *(uint32_t*)(fake_xip+FLASH_CTR_ADDR0_OFF)=1234;   /* software mode counted up to 1234 */
  j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && ctr_writes==1 && ctr_written==1234);                  /* SE enrolment keeps the counter */
  memset(fake_xip+FLASH_CTR_ADDR0_OFF,0xFF,8192); *(uint32_t*)(fake_xip+FLASH_CTR_ADDR1_OFF)=77; *(uint32_t*)(fake_xip+FLASH_CTR_ADDR0_OFF)=76;
  ctr_writes=0; j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && ctr_written==77);                                     /* picks the newer of the two sectors */
  memset(fake_xip+FLASH_CTR_ADDR0_OFF,0xFF,8192); g_se=false; secret_off=0x72000; ctr_writes=0;
  j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && ctr_written==0);                                      /* virgin flash: still starts at 0 */

  /* ---- SE enrolment destroys the software master key; software enrolment does not touch the SE salt ---- */
  g_se=true; secret_off=0x75000; erase_n=0; j=setjmp(out); if(j==0) flash_master_keygen();
  { int sw=0, salt=0; for(int k=0;k<erase_n;k++){ if(erase_log[k]==FLASH_MKEY_OFF) sw++; if(erase_log[k]==0x75000) salt++; }
    CHECK(j==2 && sw==1 && salt==1); }
  g_se=false; secret_off=0x72000; erase_n=0; j=setjmp(out); if(j==0) flash_master_keygen();
  { int sw=0, salt=0; for(int k=0;k<erase_n;k++){ if(erase_log[k]==FLASH_MKEY_OFF) sw++; if(erase_log[k]==0x75000) salt++; }
    CHECK(j==2 && sw==1 && salt==0); }                                /* software keygen erases only its own sector */
  /* chip unreadable during SE enrolment: the software key must NOT be destroyed */
  g_se=true; secret_off=0x75000; se_serial_rc=-1; erase_n=0; blink=0; j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==1 && erase_n==0); se_serial_rc=0;

  /* ---- U2F counter must never go backwards when the identity changes ---- */
  g_se=true; secret_off=0x75000; blink=0; progs=0; ctr_writes=0; ctr_written=0xDEAD; erase_n=0;
  memset(fake_xip+FLASH_CTR_ADDR0_OFF,0xFF,8192); *(uint32_t*)(fake_xip+FLASH_CTR_ADDR0_OFF)=1234;   /* software mode counted up to 1234 */
  j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && ctr_writes==1 && ctr_written==1234);                  /* SE enrolment keeps the counter */
  memset(fake_xip+FLASH_CTR_ADDR0_OFF,0xFF,8192); *(uint32_t*)(fake_xip+FLASH_CTR_ADDR1_OFF)=77; *(uint32_t*)(fake_xip+FLASH_CTR_ADDR0_OFF)=76;
  ctr_writes=0; j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && ctr_written==77);                                     /* picks the newer of the two sectors */
  memset(fake_xip+FLASH_CTR_ADDR0_OFF,0xFF,8192); g_se=false; secret_off=0x72000; ctr_writes=0;
  j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==2 && ctr_written==0);                                      /* virgin flash: still starts at 0 */

  /* ---- SE enrolment destroys the software master key; software enrolment does not touch the SE salt ---- */
  g_se=true; secret_off=0x75000; erase_n=0; j=setjmp(out); if(j==0) flash_master_keygen();
  { int sw=0, salt=0; for(int k=0;k<erase_n;k++){ if(erase_log[k]==FLASH_MKEY_OFF) sw++; if(erase_log[k]==0x75000) salt++; }
    CHECK(j==2 && sw==1 && salt==1); }
  g_se=false; secret_off=0x72000; erase_n=0; j=setjmp(out); if(j==0) flash_master_keygen();
  { int sw=0, salt=0; for(int k=0;k<erase_n;k++){ if(erase_log[k]==FLASH_MKEY_OFF) sw++; if(erase_log[k]==0x75000) salt++; }
    CHECK(j==2 && sw==1 && salt==0); }                                /* software keygen erases only its own sector */
  /* chip unreadable during SE enrolment: the software key must NOT be destroyed */
  g_se=true; secret_off=0x75000; se_serial_rc=-1; erase_n=0; blink=0; j=setjmp(out); if(j==0) flash_master_keygen();
  CHECK(j==1 && erase_n==0); se_serial_rc=0;
  printf(fails?"FAILURES %d\n":"integration (device_kdf / chip binding / enrolment / rotation): all pass\n",fails); return fails!=0;
}
