Secure-element tests. Self-contained: ./run_all.sh <patched-repo-root>   (gcc with ASan/UBSan + python3; no wolfSSL / pico-sdk)

  t_se.py       real src/se.c against a behavioural model of the ATECC608 command protocol (datasheet framing, CRC16,
                wake pulse, sleep, busy NACK, statuses, HMAC through the SHA command, READ POINTER: an answer is read as
                2-byte head then count-2 bytes, as Microchip's hal_i2c_receive does; wake answer retries; HMAC End = mode 0x02 as in cryptoauthlib for the 608, mode 0x05 is rejected like a real 608 would). Checks jumper detection, every fail-closed path, HMAC ==
                HMAC-SHA256(slot key) at all block boundaries, no read beyond the answer, bounded busy wait, 6000 hostile-chip rounds.
  t_int.c       device_kdf / chip binding / SE enrolment (counter kept, software key destroyed) / reset rotation, taken
                verbatim out of src/u2f.c
  rt_se.c       src/rand.c: chip entropy really influences the seed, chip failure fails the seed, software mode never calls the chip

The model was written from the datasheet and from how Microchip's library talks to the chip. It is NOT validated on silicon.
