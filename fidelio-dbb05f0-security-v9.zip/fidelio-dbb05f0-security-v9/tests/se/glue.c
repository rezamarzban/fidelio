/* Host glue: the Pico SDK I2C/GPIO/time + the few wolfCrypt HMAC calls se.c uses, routed to Python */
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
typedef struct i2c_inst { int x; } i2c_inst_t; i2c_inst_t i2c0_inst;
typedef int (*wr_cb)(uint8_t addr, const uint8_t *d, size_t n);
typedef int (*rd_cb)(uint8_t addr, uint8_t *d, size_t n);
typedef int (*pin_get_cb)(uint32_t pin);
typedef void (*pin_put_cb)(uint32_t pin, int v);
typedef void (*wake_cb)(uint64_t low_us);
typedef void (*hmac_cb)(const uint8_t *key, size_t kl, const uint8_t *msg, size_t ml, uint8_t *out);
wr_cb g_wr; rd_cb g_rd; pin_get_cb g_pget; pin_put_cb g_pput; hmac_cb g_hmac; wake_cb g_wake; static int sda_mode_sio; static int sda_val=1; static uint64_t sda_low_t0; static int sda_low; uint64_t g_time_us;
long g_i2c_calls, g_sleep_calls;
void set_cbs(wr_cb w, rd_cb r, pin_get_cb pg, pin_put_cb pp, hmac_cb h, wake_cb wk){ g_wr=w; g_rd=r; g_pget=pg; g_pput=pp; g_hmac=h; g_wake=wk; }
unsigned i2c_init(i2c_inst_t*i, unsigned b){(void)i;return b;} unsigned i2c_set_baudrate(i2c_inst_t*i, unsigned b){(void)i;return b;}
int i2c_write_timeout_us(i2c_inst_t*i,uint8_t a,const uint8_t*d,size_t n,bool nostop,uint32_t t){(void)i;(void)nostop;(void)t;g_i2c_calls++;return g_wr(a,d,n);}
int i2c_read_timeout_us(i2c_inst_t*i,uint8_t a,uint8_t*d,size_t n,bool nostop,uint32_t t){(void)i;(void)nostop;(void)t;g_i2c_calls++;return g_rd(a,d,n);}
void gpio_init(uint32_t p){(void)p;} void gpio_set_dir(uint32_t p,int o){(void)p;(void)o;} void gpio_pull_up(uint32_t p){(void)p;}
void gpio_disable_pulls(uint32_t p){(void)p;}
void gpio_set_function(uint32_t p,int f){ if(p==4){ if(f==5){ sda_mode_sio=1; if(sda_val==0 && !sda_low){ sda_low=1; sda_low_t0=g_time_us; } }
    else { if(sda_mode_sio && sda_low){ g_wake(g_time_us - sda_low_t0); } sda_mode_sio=0; sda_low=0; sda_val=1; } } }
void gpio_put(uint32_t p,int v){ if(p==4){ sda_val=v; if(sda_mode_sio && v==0 && !sda_low){ sda_low=1; sda_low_t0=g_time_us; } return; } g_pput(p,v); }
int gpio_get(uint32_t p){ return g_pget(p); }
void sleep_us(uint64_t u){ g_time_us+=u; g_sleep_calls++; } void sleep_ms(uint32_t m){ g_time_us+=(uint64_t)m*1000; g_sleep_calls++; }
/* HMAC state for the blank-key probe */
static uint8_t hk[64]; static size_t hkl; static uint8_t hb[512]; static size_t hbl;
typedef struct { int x; } Hmac;
int wc_HmacInit(Hmac*h,void*a,int b){(void)h;(void)a;(void)b;hbl=0;return 0;}
int wc_HmacSetKey(Hmac*h,int t,const uint8_t*k,uint32_t n){(void)h;(void)t;hkl=n>64?64:n;memcpy(hk,k,hkl);return 0;}
int wc_HmacUpdate(Hmac*h,const uint8_t*d,uint32_t n){(void)h;memcpy(hb+hbl,d,n);hbl+=n;return 0;}
int wc_HmacFinal(Hmac*h,uint8_t*o){(void)h;g_hmac(hk,hkl,hb,hbl,o);return 0;}
void wc_HmacFree(Hmac*h){(void)h;}
