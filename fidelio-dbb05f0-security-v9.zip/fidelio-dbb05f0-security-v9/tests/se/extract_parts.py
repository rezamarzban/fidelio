# Pull device_kdf / device_se_check / flash_master_keygen / device_rotate_secret VERBATIM out of src/u2f.c into parts.h
import sys
src = open(sys.argv[1] + "/src/u2f.c").read()
def fn(start):
    a = src.index(start); b = src.index("\n}\n", a) + 3; return src[a:b]
a = src.index("#define SE_SERIAL_OFF_IN_PAGE"); b = src.index("/* Run flash ops from RAM", a)
out = "#define SE_SERIAL_OFF_IN_PAGE 36\n" + fn("static uint32_t U2F_Counter_load(void)\n{") + "\n" + fn("int device_kdf(") + "\n" + fn("int device_se_check(void)") + "\n" + \
      src[a:b].replace("#define SE_SERIAL_OFF_IN_PAGE 36\n", "") + "\n" + fn("static void __not_in_flash_func(flash_master_keygen)") + "\n" + fn("int __not_in_flash_func(device_rotate_secret)")
out = "static uint32_t U2F_Counter_load(void);\n" + out
open("parts.h", "w").write(out)
