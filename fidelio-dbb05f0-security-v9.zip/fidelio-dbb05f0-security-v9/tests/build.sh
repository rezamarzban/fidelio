#!/bin/sh
# usage: build.sh <srcdir> <out> [sw|se] [extra gcc flags]
#   sw (default): software crypto, SE driver replaced by se_off.c (se_active() == false)
#   se          : se_on.c = a simulated chip (HMAC with a fixed slot key via real wolfCrypt); run with RIG_SE=1
# Paths: WOLFSSL = wolfSSL checkout, HERE = this directory.  Adjust the two lines below.
WOLFSSL=${WOLFSSL:-/tmp/fidelio/lib/wolfssl}
HERE=$(cd "$(dirname "$0")" && pwd)
SRC=$1; OUT=$2; MODE=${3:-sw}; [ $# -ge 3 ] && shift 3 || shift 2
STUB=$HERE/se_off.c; [ "$MODE" = se ] && STUB=$HERE/se_on.c
mkdir -p /tmp/rig_inc
sed 's/^#define WOLFSSL_SP_ARM_THUMB_ASM/\/\/ host/' $SRC/src/user_settings.h > /tmp/rig_inc/user_settings.h
FILES=""
for s in asn wc_port wolfmath hash memory misc ecc hmac coding random aes sha256 sha512 ge_low_mem fe_low_mem ge_operations wc_encrypt pwdbased sp_int sp_c32 kdf logging error; do
  [ -f $WOLFSSL/wolfcrypt/src/$s.c ] && FILES="$FILES $WOLFSSL/wolfcrypt/src/$s.c"
done
gcc -O1 -g -w "$@" -DWOLFSSL_USER_SETTINGS -I/tmp/rig_inc -I$HERE/stubs -I$SRC/src -I$WOLFSSL \
    -o $OUT $HERE/rig.c $SRC/src/u2f.c $SRC/src/ctap2.c $SRC/src/cert.c $STUB $FILES
