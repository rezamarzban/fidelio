#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include "wolfssl/wolfcrypt/settings.h"
#include "wolfssl/wolfcrypt/hmac.h"
bool se_active(void){return 1;}
static const uint8_t slot[32]={9,8,7,6,5,4,3,2,1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22};
int se_serial(uint8_t o[9]){ const char*e=getenv("RIG_SERIAL"); memset(o,0,9); o[0]=e?e[0]:1; o[1]=2;o[2]=3;o[3]=4;o[4]=5;o[5]=6;o[6]=7;o[7]=8;o[8]=9; return 0;}
int se_random32(uint8_t o[32]){FILE*f=fopen("/dev/urandom","rb");size_t n=fread(o,1,32,f);(void)n;fclose(f);return 0;}
int se_hmac(const uint8_t*m,size_t l,uint8_t o[32]){ Hmac h; if(wc_HmacInit(&h,NULL,0))return -1; if(wc_HmacSetKey(&h,WC_SHA256,slot,32))return -1; wc_HmacUpdate(&h,m,(word32)l); wc_HmacFinal(&h,o); wc_HmacFree(&h); return 0; }
