#!/bin/sh
cd /tmp/h2
W=/tmp/fidelio/lib/wolfssl/wolfcrypt/src
FILES=""
for s in asn wc_port wolfmath hash memory misc ecc hmac coding random aes sha256 sha512 ge_low_mem fe_low_mem ge_operations wc_encrypt pwdbased sp_int sp_c32 kdf logging error; do
  [ -f $W/$s.c ] && FILES="$FILES $W/$s.c"
done
gcc -O1 -w -DWOLFSSL_USER_SETTINGS -I/tmp/h2/host_inc -I/tmp/fidelio/lib/wolfssl -o det det.c $FILES 2>&1 | head -5
./det
