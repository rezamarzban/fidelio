#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
bool se_active(void){return false;}
int se_serial(uint8_t o[9]){(void)o;return -1;}
int se_random32(uint8_t o[32]){(void)o;return -1;}
int se_hmac(const uint8_t*m,size_t l,uint8_t o[32]){(void)m;(void)l;(void)o;return -1;}
