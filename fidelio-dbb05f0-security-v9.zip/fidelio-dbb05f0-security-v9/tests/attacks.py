import sys; sys.path.insert(0,'/tmp/h2')
from drv import *
import struct, os
exe=sys.argv[1]; fl=sys.argv[2]; tag=sys.argv[3]
new_flash(fl); run(exe,fl,[],button="down")   # first boot provisioning
res={}
def leaky(f, start): return any(b==0xfe for b in f[start:])
# --- 1. stack disclosure
rc,rep,_=run(exe,fl,frames(0x06,bytes(range(8)))); res["INIT reply tail clean"]=not leaky(rep[0],24) and not any(rep[0][24:])
rc,rep,_=run(exe,fl,frames(0x03,apdu(3,0,b""))); f=rep[0]; res["U2F VERSION reply tail clean"]= (not leaky(f,16)) and not any(f[16:]) if len(rep) else False
rc,rep,_=run(exe,fl,frames(0x3f,b"\x00")); f=rep[0] if rep else b"\xff"*64; res["unknown-cmd error reply clean"]= len(rep)>0 and not any(f[8:])
rc,rep,_=run(exe,fl,frames(0x10,b"\x06\xa1\x01")); f=rep[0] if rep else b"\xff"*64; res["malformed clientPIN error reply clean"]= len(rep)>0 and not any(f[8:])
# --- register a credential with presence
rc,rep,_=run(exe,fl,frames(0x03,apdu(1,3,CH+APP)),button="toggle")
m=assemble(rep); pay=m[0][1]; assert pay[0]==5, pay[:4].hex()
handle=pay[67:131]; assert pay[66]==64
auth=lambda p1,h=handle: frames(0x03,apdu(2,p1,CH+APP+bytes([len(h)])+h))
# --- 2. 0x08 sign-without-presence with button NEVER pressed
rc,rep,err=run(exe,fl,auth(0x08),button="up",maxsleeps=2000); m=assemble(rep)
res["no silent sign (p1=0x08, button up)"]= not (m and len(m[0][1])>70 and m[0][1][-2:]==b"\x90\x00" and m[0][1][0]==0)
# --- 3. unbounded wait: p1=0x03, button never pressed
rc,rep,err=run(exe,fl,auth(0x03),button="up",maxsleeps=20000)
res["presence wait is bounded (returns an error, no hang)"]= rc!=77
# --- 4. wrong key handle must not ask for a button press first
bad=bytes(64)
rc,rep,err=run(exe,fl,auth(0x03,bad),button="up",maxsleeps=20000)
res["foreign handle rejected without waiting for button"]= rc!=77
# --- 5. stuck/held button must not auto-approve: button already down at request time
rc,rep,err=run(exe,fl,auth(0x03),button="down",maxsleeps=20000); m=assemble(rep)
res["already-held button does not approve"]= not bool(m and m[0][1][:1]==b"\x01")
rc,rep,err=run(exe,fl,auth(0x03),button="toggle"); m=assemble(rep)
res["legit tap still signs (U2F auth)"]= bool(m and m[0][1][:1]==b"\x01" and m[0][1][-2:]==b"\x90\x00")
# --- 6. replay of finished message by a stray continuation frame
fr=auth(0x03); nseq=len(fr)-1; fr=fr+[cont(nseq)]
rc,rep,err=run(exe,fl,fr,button="toggle"); m=assemble(rep)
n_sig=sum(1 for c,d in m if len(d)>70 and d[-2:]==b"\x90\x00")
res["finished request is not replayable by stray continuation"]= n_sig==1
# --- 7. CTAP2 reset without presence
rc,rep,err=run(exe,fl,frames(0x10,b"\x07"),button="up",maxsleeps=20000); m=assemble(rep)
res["CTAP2 reset needs presence"]= not (m and m[0][1][:1]==b"\x00")
# --- 8. CBOR length overflow in text length (rp id len 0xFFFFFFFB) -> crash/hang?
cdh=b"\xaa"*32
algs=b"\x04\x81\xa2\x63alg\x26\x64type\x6apublic-key"
mc=b"\x01"+bytes([0xA4])+b"\x01\x58\x20"+cdh+b"\x02\xa1\x62id\x7a\xff\xff\xff\xfb"+b"A"*8+algs
rc,rep,err=run(exe,fl,frames(0x10,mc),button="toggle",maxsleeps=20000)
res["oversized CBOR text length does not crash"]= rc in (0,) 
print("=== %s ==="%tag)
for k,v in res.items(): print(("PASS " if v else "FAIL ")+k)
