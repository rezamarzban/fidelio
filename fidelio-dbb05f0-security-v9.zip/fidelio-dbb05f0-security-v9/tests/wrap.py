import sys; sys.path.insert(0,'/tmp/h2')
from drv import *
exe=sys.argv[1]; fl="/tmp/h2/f_wrap.bin"; new_flash(fl); run(exe,fl,[],button="down")
cdh=b"\xaa"*32
algs=b"\x04\x81\xa2\x63alg\x26\x64type\x6apublic-key"
mc=b"\x01"+bytes([0xA3])+b"\x01\x58\x20"+cdh+algs+b"\x02\xa1\x62id\x7a\xff\xff\xff\xfb"
rc,rep,err=run(exe,fl,frames(0x10,mc),button="toggle",maxsleeps=200000)
print("rc",rc, "reply status:", assemble(rep)[0][1][:1].hex() if assemble(rep) else None); print(err[:400])
