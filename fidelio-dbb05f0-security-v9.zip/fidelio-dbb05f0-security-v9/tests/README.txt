Host-side (x86 Linux) test rig. It compiles the REAL src/u2f.c, src/ctap2.c and wolfCrypt against stubbed pico-sdk/TinyUSB
headers, feeds raw 64-byte HID frames to it, simulates flash (a write to a non-erased cell aborts) and the presence button.

  build.sh <srcdir> <out> [sw|se] [gcc flags]    build the rig; WOLFSSL=<wolfssl checkout> (default /tmp/fidelio/lib/wolfssl)
                                                 add -fsanitize=address,undefined -fno-sanitize=shift for the sanitizer build
                                                 'se' links a simulated chip (se_on.c); run those tests with RIG_SE=1
  attacks.py   <bin> <flash> <tag>   raw-protocol attack checks (leaks, presence, replay, reset ...)        12 checks
  func.py      <bin> <flash> <tag>   python-fido2 functional+security checks (U2F, CTAP2, PIN, CBOR)        24 checks
  transport.py <bin>                 CTAPHID channel isolation, timeout, INIT, PING, WINK                   19 checks
  resettest.py <bin>                 reset invalidates every credential and the PIN                          7 checks
  modeswitch.py <sw-bin> <se-bin>    software <-> SE switching: counter never decreases, software key destroyed,
                                     no downgrade, chip swap refused                                        11 checks
  fuzz.py      <bin> <n> [seed]      mutation fuzzing of CTAP2 commands (sanitizer build; also run it with the 'se' rig)
  wrap.py      <bin>                 CBOR 32-bit length wrap-around exploit (crashes the original firmware)
  rundet.sh                          RFC 6979 determinism unit test with the project wolfSSL settings
  se/                                secure-element driver tests, see se/README.txt

NOT covered: real USB, real flash timing, real ADC/ROSC entropy, the physical button, a real ATECC608, physical attacks.
