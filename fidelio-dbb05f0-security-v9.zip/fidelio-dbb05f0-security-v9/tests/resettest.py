import sys, os, hashlib
sys.path.insert(0, "/tmp/h2")
from drv import *
from client import *
from fido2.ctap1 import Ctap1, RegistrationData, ApduError
from fido2.ctap2 import Ctap2, ClientPin
from fido2.ctap2.pin import PinProtocolV2
from fido2.ctap import CtapError
from fido2.cose import CoseKey

exe = sys.argv[1]
fl = "/tmp/h2/f_reset.bin"
new_flash(fl)
os.system("RIG_BUTTON=down %s %s </dev/null" % (exe, fl))
res = []


def chk(n, ok, info=""):
    res.append((n, bool(ok), info))


app = hashlib.sha256(b"https://example.com").digest()
ch = os.urandom(32)
rp = {"id": "example.com", "name": "x"}
user = {"id": b"\x01", "name": "b"}
cdh = os.urandom(32)

# --- state before reset: U2F registration, CTAP2 credential, PIN
dev, conn = open_dev(exe, fl)
rd = Ctap1(dev).register(ch, app)
conn.close()
dev, conn = open_dev(exe, fl)
ct = Ctap2(dev)
mc = ct.make_credential(cdh, rp, user, [{"type": "public-key", "alg": -7}])
cid = mc.auth_data.credential_data.credential_id
ClientPin(ct, PinProtocolV2()).set_pin("123456")
conn.close()

# --- reset
dev, conn = open_dev(exe, fl)
ct = Ctap2(dev)
try:
    ct.reset()
    chk("reset succeeds (tap, inside power-up window)", True)
except CtapError as e:
    chk("reset succeeds (tap, inside power-up window)", False, hex(e.code))
conn.close()

# --- after reset
dev, conn = open_dev(exe, fl)
c1 = Ctap1(dev)
try:
    c1.authenticate(ch, app, RegistrationData(rd).key_handle)
    chk("old U2F registration is dead after reset", False, "still authenticates")
except ApduError as e:
    chk("old U2F registration is dead after reset", e.code == 0x6A80, hex(e.code))
ct = Ctap2(dev)
chk("PIN cleared by reset", not ct.get_info().options.get("clientPin"))
try:
    ct.get_assertion("example.com", cdh, [{"type": "public-key", "id": cid}])
    chk("old CTAP2 credential is dead after reset", False, "still works")
except CtapError as e:
    chk("old CTAP2 credential is dead after reset", e.code == 0x2E, hex(e.code))
conn.close()

# --- the device still works, fresh credentials, counter keeps increasing
dev, conn = open_dev(exe, fl)
c1 = Ctap1(dev)
ch2 = os.urandom(32)
rd2 = c1.register(ch2, app)
RegistrationData(rd2).verify(app, ch2)
sd = c1.authenticate(ch2, app, RegistrationData(rd2).key_handle)
sd.verify(app, ch2, RegistrationData(rd2).public_key)
chk("new U2F registration works after reset", True)
ct = Ctap2(dev)
mc2 = ct.make_credential(cdh, rp, user, [{"type": "public-key", "alg": -7}])
a = ct.get_assertion("example.com", cdh, [{"type": "public-key", "id": mc2.auth_data.credential_data.credential_id}])
CoseKey.parse(mc2.auth_data.credential_data.public_key).verify(a.auth_data + cdh, a.signature)
chk("new CTAP2 credential works after reset", True)
conn.close()

# --- master key really changed (flash content differs, magic intact)
raw = open(fl, "rb").read()
chk("master key page has valid magic", raw[0x72000:0x72004] == bytes.fromhex("c091d0f1"))

print("=== RESET ===")
for n, ok, i in res:
    print(("PASS " if ok else "FAIL ") + n + (("   [" + i + "]") if i else ""))
