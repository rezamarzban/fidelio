#include <stdio.h>
#include <string.h>
#include "wolfssl/wolfcrypt/settings.h"
#include "wolfssl/wolfcrypt/ecc.h"
#include "wolfssl/wolfcrypt/random.h"
int custom_random_seed(unsigned char*o,unsigned int sz){FILE*f=fopen("/dev/urandom","rb");size_t n=fread(o,1,sz,f);(void)n;fclose(f);return 0;}
int main(void){
  WC_RNG rng; ecc_key k; byte d[32],d2[32],s1[80],s2[80],s3[80]; word32 l1=80,l2=80,l3=80; int ok=0;
  memset(d,0x5a,32); wc_InitRng(&rng); wc_ecc_init(&k);
  wc_ecc_import_private_key_ex(d,32,NULL,0,&k,ECC_SECP256R1); wc_ecc_make_pub_ex(&k,NULL,NULL);
  wc_ecc_set_deterministic(&k,1);
  wc_ecc_sign_hash(d,32,s1,&l1,&rng,&k); wc_ecc_sign_hash(d,32,s2,&l2,&rng,&k);
  printf("deterministic: identical signatures for identical input: %s\n",(l1==l2&&!memcmp(s1,s2,l1))?"YES":"NO");
  wc_ecc_verify_hash(s1,l1,d,32,&ok,&k); printf("signature verifies: %s\n",ok?"YES":"NO");
  memcpy(d2,d,32); d2[0]^=1; wc_ecc_sign_hash(d2,32,s3,&l3,&rng,&k);
  printf("different message -> different signature: %s\n",(l3!=l1||memcmp(s1,s3,l1))?"YES":"NO");
  wc_ecc_set_deterministic(&k,0); l2=80; wc_ecc_sign_hash(d,32,s2,&l2,&rng,&k);
  printf("(control) randomized signing differs: %s\n",(l1==l2&&!memcmp(s1,s2,l1))?"NO (unexpected)":"YES");
  return 0; }
