import sys, os, hashlib, struct, time
sys.path.insert(0,'/tmp/h2')
from client import *
from fido2.ctap1 import Ctap1, RegistrationData, SignatureData
from fido2.ctap2 import Ctap2, ClientPin
from fido2.ctap2.pin import PinProtocolV2
from fido2.ctap import CtapError
from fido2 import cbor
from fido2.cose import CoseKey
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidSignature
exe=sys.argv[1]; fl=sys.argv[2]; tag=sys.argv[3]
if os.path.exists(fl): os.remove(fl)
os.system(f"RIG_BUTTON=down {exe} {fl} </dev/null")
res=[]
def T(name, fn):
    try:
        r=fn(); res.append((name, bool(r) if r is not None else True, ""))
    except CtapError as e:
        res.append((name, False, "CtapError 0x%02x"%e.code))
    except Exception as e:
        res.append((name, False, type(e).__name__+": "+str(e)[:80]))
def session(button="toggle"):
    dev,conn=open_dev(exe,fl,button); return dev,conn
def code(fn):
    try: fn(); return 0
    except CtapError as e: return int(e.code)

# ---------- U2F
app=hashlib.sha256(b"https://example.com").digest(); ch=os.urandom(32)
dev,conn=session(); c1=Ctap1(dev)
state={}
def u2f_reg():
    rd=c1.register(ch,app); state['rd']=rd
    RegistrationData(rd).verify(app,ch)   # verifies attestation signature with the embedded cert
    return True
T("U2F register + attestation signature verifies", u2f_reg)
def u2f_auth():
    rd=RegistrationData(state['rd']); sd=c1.authenticate(ch,app,rd.key_handle)
    sd.verify(app,ch,rd.public_key); return sd.user_presence==1
T("U2F authenticate signature verifies", u2f_auth)
def u2f_check():
    rd=RegistrationData(state['rd'])
    try: c1.authenticate(ch,app,rd.key_handle,check_only=True)
    except ApduError as e: return e.code==0x6985
    return False
from fido2.ctap1 import ApduError
T("U2F check-only answers 0x6985 for own handle", u2f_check)
def u2f_foreign():
    try: c1.authenticate(ch,app,os.urandom(64))
    except ApduError as e: return e.code==0x6a80
    return False
T("U2F foreign handle -> 0x6a80", u2f_foreign)
T("U2F version", lambda: c1.get_version()=="U2F_V2")
conn.close()

# ---------- CTAP2 MC / GA
rp={"id":"example.com","name":"ex"}; user={"id":b"\x01\x02","name":"bob"}
cdh=os.urandom(32); params=[{"type":"public-key","alg":-7}]
dev,conn=session(); ctap=Ctap2(dev)
def mc():
    r=ctap.make_credential(cdh,rp,user,params)
    ad=r.auth_data; state['cred']=ad.credential_data
    pk=CoseKey.parse(ad.credential_data.public_key); state['pk']=pk
    return True
T("CTAP2 makeCredential", mc)
def ga():
    cd=state['cred']
    a=ctap.get_assertion("example.com",cdh,[{"type":"public-key","id":cd.credential_id}])
    state['pk'].verify(a.auth_data+cdh, a.signature); return True
T("CTAP2 getAssertion signature verifies", ga)
T("CTAP2 GA with unknown credential -> NO_CREDENTIALS", lambda: code(lambda: ctap.get_assertion("example.com",cdh,[{"type":"public-key","id":os.urandom(64)}]))==0x2e)
# U2F-registered handle works through CTAP2? (compat, informational)
conn.close()

# ---------- CBOR nesting depth
dev,conn=session(); ctap=Ctap2(dev); cdh=os.urandom(32)
def nested(n): 
    return b"\x81"*n+b"\x00"
def mc_deep(n):
    r=code(lambda: ctap.send_cbor(0x01, {1:cdh,2:rp,3:user,4:params,0x20:cbor.decode(nested(n))}))
    return r
res.append(("shallow unknown field (depth 4) is accepted", mc_deep(4)==0, ""))
rd=mc_deep(200)
res.append(("200-deep nested CBOR is refused", rd!=0, "code=0x%02x"%rd))
conn.close()

# ---------- PIN
dev,conn=session(); ctap=Ctap2(dev); cp=ClientPin(ctap, PinProtocolV2())
T("setPIN 4 chars", lambda: cp.set_pin("1234") is None)
T("retries == 8", lambda: cp.get_pin_retries()[0]==8)
def wrong():
    try: cp.get_pin_token("0000")
    except CtapError as e: return e.code==0x31
    return False
T("wrong PIN -> PIN_INVALID", wrong)
T("retries == 7 after one wrong try", lambda: cp.get_pin_retries()[0]==7)
def right():
    tok=cp.get_pin_token("1234"); state['tok']=tok; return True
T("right PIN gives token", right)
T("retries restored to 8", lambda: cp.get_pin_retries()[0]==8)
def mc_pin():
    proto=PinProtocolV2(); tok=state['tok']
    uv=proto.authenticate(tok,cdh)
    r=ctap.make_credential(cdh,rp,user,params,pin_uv_param=uv,pin_uv_protocol=2); return True
T("makeCredential with PIN token", mc_pin)
T("makeCredential without PIN auth is refused", lambda: code(lambda: ctap.make_credential(cdh,rp,user,params))!=0)
# power-cut-after-wrong-guess: the counter must already be spent when the wrong answer is returned
conn.close()
# short PIN rejected: need a fresh (reset) state -> done in the reset section
# ---------- invalid-curve point must not be processed
dev,conn=session(); ctap=Ctap2(dev); cp=ClientPin(ctap, PinProtocolV2())
def badpoint():
    before=cp.get_pin_retries()[0]
    ka=ctap.client_pin(2, ClientPin.CMD.GET_KEY_AGREEMENT)[1]
    bad={1:2,3:-25,-1:1,-2:os.urandom(32),-3:os.urandom(32)}
    try:
        ctap.client_pin(2, ClientPin.CMD.GET_TOKEN_USING_PIN_LEGACY, key_agreement=bad, pin_hash_enc=os.urandom(32))
        r=0
    except CtapError as e: r=int(e.code)
    after=cp.get_pin_retries()[0]
    state['bad']=(before,after,r); return True
T("invalid-curve ECDH point (probe)", badpoint)
b=state.get('bad'); 
res.append(("invalid-curve point rejected without spending a PIN retry", bool(b) and b[0]==b[1], "before=%s after=%s err=%s"%b if b else ""))
conn.close()

# ---------- reset
dev,conn=session("toggle"); ctap=Ctap2(dev)
def reset_ok():
    ctap.reset(); return True
T("reset right after power-up with a tap works", reset_ok)
cpx=ClientPin(ctap, PinProtocolV2())
T("PIN cleared by reset (clientPin false)", lambda: not Ctap2(dev).get_info().options.get("clientPin"))
def short_pin():
    ct=Ctap2(dev); proto=PinProtocolV2(); cpx=ClientPin(ct,proto)
    ka,sh=cpx._get_shared_secret()
    pad=b"12"+b"\x00"*62
    enc=proto.encrypt(sh,pad); par=proto.authenticate(sh,enc)
    return code(lambda: ct.client_pin(2,ClientPin.CMD.SET_PIN,key_agreement=ka,new_pin_enc=enc,pin_uv_param=par))
sp=short_pin(); res.append(("short PIN (2 chars) refused by firmware (0x37)", sp==0x37, "code=0x%02x"%sp))
conn.close()
# reset after the boot window: advance the rig clock past 10 s with the test hook
try:
    dev,conn=session("up")
    ctap=Ctap2(dev)
    for _ in range(3): conn.write_packet(b"\xee\xee\xee\xee"+bytes(60))
    r=code(lambda: ctap.reset())
    res.append(("reset after the 10 s boot window is refused (0x30)", r==0x30, "code=0x%02x"%r))
    conn.close()
except Exception as e:
    res.append(("reset after the 10 s boot window is refused (0x30)", False, "device hung/crashed: "+type(e).__name__))
w=max(len(n) for n,_,_ in res)
print("=== %s ==="%tag)
for n,ok,info in res: print(("PASS " if ok else "FAIL ")+n+(("   ["+info+"]") if info else ""))
