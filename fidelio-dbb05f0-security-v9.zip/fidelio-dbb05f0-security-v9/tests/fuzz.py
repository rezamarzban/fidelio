import sys, random, os
sys.path.insert(0,'/tmp/h2')
from drv import *
from fido2 import cbor
exe=sys.argv[1]; fl="/tmp/h2/f_fuzz.bin"; n=int(sys.argv[2]); seed=int(sys.argv[3]) if len(sys.argv)>3 else 1
random.seed(seed); new_flash(fl); run(exe,fl,[],button="down")
cdh=os.urandom(32)
seeds=[
 b"\x01"+cbor.encode({1:cdh,2:{"id":"example.com","name":"x"},3:{"id":b"\x01","name":"b"},4:[{"type":"public-key","alg":-7}],7:{"rk":True}}),
 b"\x02"+cbor.encode({1:"example.com",2:cdh,3:[{"type":"public-key","id":os.urandom(64)}]}),
 b"\x06"+cbor.encode({1:2,2:2}),
 b"\x06"+cbor.encode({1:2,2:3,3:{1:2,3:-25,-1:1,-2:os.urandom(32),-3:os.urandom(32)},4:os.urandom(32),5:os.urandom(80)}),
 b"\x06"+cbor.encode({1:2,2:5,3:{1:2,3:-25,-1:1,-2:os.urandom(32),-3:os.urandom(32)},6:os.urandom(32)}),
 b"\x04",
]
def mutate(b):
    b=bytearray(b)
    for _ in range(random.randint(1,5)):
        r=random.random(); 
        if r<.5 and len(b)>1: b[random.randrange(1,len(b))]=random.randrange(256)
        elif r<.7 and len(b)>2: del b[random.randrange(1,len(b))]
        elif r<.85: b.insert(random.randrange(1,len(b)+1), random.choice([0x81,0xa1,0x9f,0xff,0x5b,0x7b,0x5a,0x7a]))
        else: b+=bytes(random.randrange(256) for _ in range(random.randint(1,20)))
    return bytes(b)
frs=[]
for i in range(n):
    m=mutate(random.choice(seeds))
    if random.random()<0.05: m=b"\x01"+bytes([0x81])*random.randint(50,400)
    frs+=frames(0x10,m)
rc,rep,err=run(exe,fl,frs,button="toggle",timeout=280)
print("rc",rc,"frames out",len(rep)); print(err[:1500])
