"""Software <-> secure-element mode switching, on the real u2f.c.
usage: modeswitch.py <software-rig> <se-rig>"""
import sys, os, hashlib, subprocess
sys.path.insert(0, "/tmp/h2")
from drv import *
from client import *
from fido2.ctap1 import Ctap1, RegistrationData, ApduError

SW, SE = sys.argv[1], sys.argv[2]
fl = "/tmp/h2/f_mode.bin"
new_flash(fl)
app = hashlib.sha256(b"https://example.com").digest()
res = []


def chk(n, ok, info=""):
    res.append((n, bool(ok), info))


def boot(exe, se):
    env = dict(os.environ, RIG_BUTTON="down")
    env.pop("RIG_SE", None)
    if se:
        env["RIG_SE"] = "1"
    subprocess.run([exe, fl], stdin=subprocess.DEVNULL, env=env, capture_output=True)


def session(exe, se):
    if se:
        os.environ["RIG_SE"] = "1"
    else:
        os.environ.pop("RIG_SE", None)
    return open_dev(exe, fl)


# 1) software mode: enrol, register, use a few times
boot(SW, False)
dev, conn = session(SW, False)
c1 = Ctap1(dev)
rd_sw = c1.register(os.urandom(32), app)
for _ in range(5):
    sd = c1.authenticate(os.urandom(32), app, RegistrationData(rd_sw).key_handle)
ctr_sw = sd.counter
conn.close()
raw = open(fl, "rb").read()
key_sw = raw[0x72004:0x72024]
chk("software mode: master key is in flash", raw[0x72000:0x72004] == bytes.fromhex("c091d0f1"))

# 2) first SE-mode boot (enrolment)
boot(SE, True)
raw = open(fl, "rb").read()
chk("after SE enrolment the software master key is ERASED from flash",
    raw[0x72000:0x72000 + 4096] == b"\xff" * 4096)
chk("SE salt record written", raw[0x75000:0x75004] == bytes.fromhex("c091d0f1"))
dev, conn = session(SE, True)
c1 = Ctap1(dev)
try:
    c1.authenticate(os.urandom(32), app, RegistrationData(rd_sw).key_handle)
    chk("old software registration is dead in SE mode", False, "still works")
except ApduError as e:
    chk("old software registration is dead in SE mode", e.code == 0x6A80, hex(e.code))
rd_se = c1.register(os.urandom(32), app)
sd = c1.authenticate(os.urandom(32), app, RegistrationData(rd_se).key_handle)
chk("U2F counter did not go backwards at SE enrolment", sd.counter > ctr_sw,
    "was %d, now %d" % (ctr_sw, sd.counter))
ctr_se = sd.counter
conn.close()

# 3) jumper removed again: the old software identity must NOT come back
boot(SW, False)
dev, conn = session(SW, False)
c1 = Ctap1(dev)
for name, rd in (("software", rd_sw), ("SE", rd_se)):
    try:
        c1.authenticate(os.urandom(32), app, RegistrationData(rd).key_handle)
        chk("jumper removed: old %s registration must not work" % name, False, "works")
    except ApduError as e:
        chk("jumper removed: old %s registration must not work" % name, e.code == 0x6A80, hex(e.code))
rd_new = c1.register(os.urandom(32), app)
sd = c1.authenticate(os.urandom(32), app, RegistrationData(rd_new).key_handle)
chk("fresh software identity works; counter still monotonic", sd.counter > ctr_se,
    "was %d, now %d" % (ctr_se, sd.counter))
conn.close()
raw = open(fl, "rb").read()
chk("new software key differs from the destroyed one", raw[0x72004:0x72024] != key_sw)

# 4) jumper fitted again: the SE identity returns (same chip, same salt)
dev, conn = session(SE, True)
c1 = Ctap1(dev)
try:
    c1.authenticate(os.urandom(32), app, RegistrationData(rd_se).key_handle)
    chk("re-fitting jumper + same chip restores the SE identity", True)
except ApduError as e:
    chk("re-fitting jumper + same chip restores the SE identity", False, hex(e.code))
conn.close()

# 5) a different chip (serial changed) is refused
p = subprocess.run([SE, fl], stdin=subprocess.DEVNULL,
                   env=dict(os.environ, RIG_SE="1", RIG_SERIAL="Z", RIG_BUTTON="down"), capture_output=True)
chk("different chip serial -> device refuses to start (rig exit 55)", p.returncode == 55, "rc=%d" % p.returncode)

print("=== MODE SWITCH ===")
for n, ok, i in res:
    print(("PASS " if ok else "FAIL ") + n + (("   [" + i + "]") if i else ""))
