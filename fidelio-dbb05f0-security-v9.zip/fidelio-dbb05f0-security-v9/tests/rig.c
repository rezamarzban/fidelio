/* Host rig: drives the real u2f.c/ctap2.c through raw 64-byte HID frames on stdin/stdout.
 * Control: environment RIG_BUTTON = "down" (always pressed) | "up" (never) | "toggle" (alternates).
 * Presence logic: gpio_get() returns 0 when pressed. Waiting loops use sleep_ms() which advances a fake clock;
 * after RIG_MAX_SLEEPS sleeps in total with no press we exit(77) to detect unbounded waits. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include "hardware/flash.h"
#include "class/hid/hid_device.h"
uint8_t fake_flash[2*1024*1024];
static uint64_t now_us = 0;
static long sleeps = 0, max_sleeps = 3000000;
static int btn_mode = 0; /* 0 down, 1 up, 2 toggle */
static int btn_tick = 0;
void flash_range_erase(uint32_t off, uint32_t cnt){ memset(fake_flash+off,0xFF,cnt); }
void flash_range_program(uint32_t off,const uint8_t*d,uint32_t cnt){
  for(uint32_t i=0;i<cnt;i++){ if((fake_flash[off+i]&d[i])!=d[i]){fprintf(stderr,"FLASH PROGRAM ON NON-ERASED @%x\n",off+i);exit(9);} fake_flash[off+i]&=d[i]; } }
void sleep_ms(uint32_t ms){ now_us += (uint64_t)ms*1000; if(++sleeps>max_sleeps){ fprintf(stderr,"RIG: unbounded wait detected\n"); exit(77);} btn_tick++; }
uint64_t time_us_64(void){ return now_us; }
void gpio_put(uint32_t p,int v){(void)p;(void)v;}
int gpio_get(uint32_t p){ (void)p; if(btn_mode==0) return 0; if(btn_mode==1) return 1; return (btn_tick/5)%2; }
int custom_random_seed(unsigned char*o,unsigned int sz){FILE*f=fopen("/dev/urandom","rb");size_t n=fread(o,1,sz,f);(void)n;fclose(f);return 0;}
static const char*g_fl=NULL;
void rig_reboot(void){ if(g_fl){FILE*f=fopen(g_fl,"wb");fwrite(fake_flash,1,sizeof fake_flash,f);fclose(f);} exit(0); }
extern void u2f_init(void);
extern void tud_hid_set_report_cb(uint8_t,uint8_t,int,const uint8_t*,uint16_t);
extern void tud_hid_report_complete_cb(uint8_t,uint8_t const*,uint8_t);
static uint8_t q[512][64]; static int qh=0,qt=0;
int tud_hid_report(uint8_t id,const void*r,uint16_t len){ (void)id; memcpy(q[qt++&511],r,64); return 1; }
static void drain(void){ while(qh!=qt){ uint8_t p[64]; memcpy(p,q[qh++&511],64); if(write(1,p,64)<0) exit(3); tud_hid_report_complete_cb(0,p,64);} }
int main(int argc,char**argv){
  const char*b=getenv("RIG_BUTTON"); if(b){ if(!strcmp(b,"up"))btn_mode=1; else if(!strcmp(b,"toggle"))btn_mode=2; }
  const char*ms=getenv("RIG_MAX_SLEEPS"); if(ms) max_sleeps=atol(ms);
  memset(fake_flash,0xFF,sizeof fake_flash);
  const char*fl=argc>1?argv[1]:NULL; g_fl=fl;
  if(fl){ FILE*f=fopen(fl,"rb"); if(f){ if(fread(fake_flash,1,sizeof fake_flash,f)){} fclose(f);} }
  u2f_init();
  { extern int device_se_check(void); const char*se=getenv("RIG_SE"); if(se && device_se_check()!=0) { fprintf(stderr,"RIG: chip check failed\n"); return 55; } }
  uint8_t p[64];
  for(;;){ size_t got=0; while(got<64){ ssize_t n=read(0,p+got,64-got); if(n<=0){ if(fl){FILE*f=fopen(fl,"wb");fwrite(fake_flash,1,sizeof fake_flash,f);fclose(f);} return 0;} got+=n; }
    if(p[0]==0xEE&&p[1]==0xEE&&p[2]==0xEE&&p[3]==0xEE){ now_us += 5000000ULL; continue; } /* test hook: advance clock 5 s */
    tud_hid_set_report_cb(0,0,0,p,64); drain(); }
}
